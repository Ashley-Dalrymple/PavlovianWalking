% Set parameters for selective Kanerva coding
K = 5000; % number of prototypes
n = 7; % number of sensors
P = rand(K,n); % prototypes randomly distributed in sensor space
eta1 = 0.1; % ratio
eta2 = 0.025;
eta3 = 0.005;
c1 = K*eta1; % number of prototypes used to find distance from state to prototypes
c2 = K*eta2;
c3 = K*eta3;








% Time SKC
% for i = 2:(length(time)/looptime)
%     tstart = tic;
%     Snew = [max(GRFLnorm(((i-1)*looptime + 1):i*looptime));max(GRFRnorm(((i-1)*looptime + 1):i*looptime));max(sumF(((i-1)*looptime + 1):i*looptime));max(GyroLnorm(((i-1)*looptime + 1):i*looptime));max(GyroRnorm(((i-1)*looptime + 1):i*looptime));max(Velnorm(((i-1)*looptime + 1):i*looptime));max(EMAGRFL(((i-1)*looptime + 1):i*looptime));max(EMAGRFR(((i-1)*looptime + 1):i*looptime))];
%     featVect = SKC(K,n,P,c1,c2,c3,Snew);
%     tend = toc(tstart)
% end
% 
