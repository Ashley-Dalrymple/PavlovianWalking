function startwalking(hObject,~)
% startwalking: makes sure everything is ready to begin stimulation
% experiment
global Originaldata
handles = guidata(hObject);
trialtime = handles.values.trialtime;
systemperiod = handles.values.systemperiod;
handles.values.rampcounter = 1;
handles.values.rampflag = true; % start with ramping
handles.values.startflag = true;
handles.values.RampTimeSteps = 3;
handles.values.oldchanamps = zeros(16,1);
if ~handles.values.RBC
%     [PrevFileName,~,~] = uigetfile; % get previously learned weights and predictions
%     handles.values.prevfilename = PrevFileName;
%     load(PrevFileName)
    load('PrevLearnSett')
    handles.values.prevfilename = 'PrevLearnSett';
    load('DemoTrial')
    handles.values.etrace = e; %#ok<*NODEF>
    handles.values.Vold = Vold;
    handles.values.weights = w;
end

handles.values.trialnumber = get(handles.hemipanel.filenameNumber,'String');
trialnumber = (handles.values.trialnumber);
filename = handles.values.filename;
datafilename = strcat(filename,'_',trialnumber);

% Before going through the stimulation code, a few checks must be enforced.
gotime = false;
% check 1
if trialtime == 0
    h = warndlg('Please set the trial time (greater than 0)',...
        'Set Trial Time');
    uiwait(h)
else
    % check 2
        if ~all(cell2mat(get(handles.hemipanel.synergybox,'Value'))) 
           savequestion = questdlg...
           ('Not all synergies are active. Should I enable them all?');
           if strcmpi(savequestion,'yes')
               set(handles.hemipanel.synergybox,'Value',1)
               handles.values.enabledsynergies = cell2mat...
                   (get(handles.hemipanel.synergybox,'Value'));
           end
        end 
gotime = true;
end

if gotime
    % now that the trialTime is set, the settings were saved, and 
    % everything else is in order, the code will proceed to the stimulation
    % section initialize all info with sensor data collection  
    global data %#ok<TLEV>
    data = cell(floor(trialtime/systemperiod),26); 

    % define variable to store all data
    handles.values.stimVector = [165 41 0 0 3 165 41 1 0 3 165 41 2 0 3 165 41 3 ...
        0 3 165 41 4 0 3 165 41 5 0 3 165 41 6 0 3 165 41 7 0 3 165 41 8 0 ...
        3 165 41 9 0 3 165 41 10 0 3 165 41 11 0 3 165 48 0 1 0 0 0 0 0 0 0 ...
        0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 165 48 0 1]; 
    a = warndlg('Get Ready!');
    uiwait(a)
    %% Setup data acquisition and timer function
    if ~isempty(timerfind('Name','timerHemi'))
        delete(timerfind('Name','timerHemi'));
    end
    handles.timers.timerHemi = timer('Period',systemperiod,'TasksToExecute',trialtime/systemperiod,...
        'BusyMode','drop','ExecutionMode','FixedRate','Name','TimerHemi');
    guidata(hObject,handles)
    if handles.values.RBC % If RBC enabled, call RBC-algorithm
        set(handles.timers.timerHemi,'TimerFcn',{@RBC,hObject},...
            'StopFcn','toc','StartFcn','tic');
    elseif ~handles.values.RBC % if RBC not enabled, use Pavlovian control
        set(handles.timers.timerHemi,'TimerFcn',{@PavlovianControl,hObject},...
            'StopFcn','toc','StartFcn','tic');
    end
    guidata(hObject,handles)
    start(handles.timers.timerHemi)
    wait(handles.timers.timerHemi)
    htosave.channelsettings = handles.values.channelsettings; 
    htosave.musclefunctions = handles.values.musclefunctions;
    htosave.enabledsynergies = handles.values.enabledsynergies;
    htosave.OLtime = handles.values.walkingperiod; % for loading purposes
    htosave.cyclemultiplier = handles.values.cyclemultiplier;
    htosave.systemperiod = handles.values.systemperiod; 
    htosave.limbs = handles.values.limbs; 
    htosave.mass = handles.values.mass; 
    htosave.limitsettings = handles.values.limitsettings;
    htosave.limitsdisplay = handles.values.limitsdisplay;
    htosave.trialtime = handles.values.trialtime; 
    htosave.RBC = handles.values.RBC;
    htosave.alpha = handles.values.alpha;
    htosave.lambda = handles.values.lambda;
    htosave.gamma = [handles.values.gamma1,handles.values.gamma2,handles.values.gamma3];
    htosave.eta = [handles.values.eta1,handles.values.eta2,handles.values.eta3];
    htosave.numprototypes = handles.values.numprototypes;
    htosave.c = [handles.values.c1,handles.values.c2,handles.values.c3];
    htosave.numSensors = handles.values.numSensors;
    htosave.numTimeStepsEMA = handles.values.numTimeSteps;
    htosave.prevfilename = handles.values.prevfilename;
    htosave.prototypevals = handles.values.prototypes;  %#ok<STRNU>
    
    if ~handles.values.RBC % save prediction settings for next trial
        e = data{end,23}; %#ok<*NASGU>
        w = data{end,24};
        Vold = data{end,25};
        predictsettings = strcat(datafilename,'_Psett');
        save(predictsettings,'w','e','Vold')
    end
    save(datafilename,'data','htosave')
    delete(timerfind('Name','timerHemi'))  
end
disp('All Done!')
beep
[y,Fs] = audioread('ting.wav');
sound(y,Fs)
guidata(hObject,handles)
