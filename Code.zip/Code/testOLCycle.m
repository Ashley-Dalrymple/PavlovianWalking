function handles = testOLCycle(hObject)
% this function will test the cycle F-E1-E2-E3 based on an open loop 
% algorithm for set walking period set in the GUI. Stimulation
% output is 50Hz (25Hz doubled). 
handles = guidata(hObject);
% initializations
walkperiod = handles.values.walkingperiod;
cyclemult = handles.values.cyclemultiplier;
samplerate = handles.values.systemperiod;
channelsettings = handles.values.channelsettings;
handles.values.oldchanamps = zeros(16,1);
handles.values.stimVector = [165 41 0 0 3 165 41 1 0 3 165 41 2 0 3 165 41 3 ...
    0 3 165 41 4 0 3 165 41 5 0 3 165 41 6 0 3 165 41 7 0 3 165 41 8 0 ...
    3 165 41 9 0 3 165 41 10 0 3 165 41 11 0 3 165 48 0 1 0 0 0 0 0 0 0 ...
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 165 48 0 1]; 
handles.values.currentsynergy = 1;
handles.values.oldsynergy = 1;
synergypcts = zeros(4,1);
OLtimes = zeros(1,4); %#ok<PREALL> % from(1,5)
handles.values.rampcounter = 1;
handles.values.loopcount = 0;
synergypcts(1,1) = valuecheck(.2*walkperiod*1000,3,samplerate)/(1000*walkperiod);
synergypcts(2,1) = valuecheck(.2*walkperiod*1000,3,samplerate)/(1000*walkperiod);
synergypcts(4,1) = valuecheck(.3*walkperiod*1000,3,samplerate)/(1000*walkperiod); % E3, previously 0.3*walkperiod
synpcts = synergypcts;
synergypcts(3,1) = 1 - sum(synpcts);
OLtimes = synergypcts*walkperiod;
statecounts = round(OLtimes/samplerate);
% check if all synergies are active
if ~all(cell2mat(get(handles.hemipanel.synergybox,'Value')))
    savequestion = ...
        questdlg('Not all synergies are active. Enable them all?');
    if strcmpi(savequestion,'yes')
        set(handles.hemipanel.synergybox,'Value',1)
        handles.values.enabledsynergies = ...
            cell2mat(get(handles.hemipanel.synergybox,'Value'));
    end
end 

handles.values.loopcount = 0;
len=get(handles.serial.serialobj,'BytesAvailable');
if len ~= 0
    a = fread(handles.serial.serialobj,len);
end
%setup the timer function that will reload the amplitudes each time
if ~isempty(timerfind('Name','timerOL'))
    delete(timerfind('Name','timerOL'))
end
disp('start')
handles.timers.timerOL = timer('Period',samplerate,'TasksToExecute',...
    cyclemult*(walkperiod/samplerate),'BusyMode','drop','ExecutionMode',...
    'FixedRate','Name','timerOL');
guidata(hObject,handles)
set(handles.timers.timerOL,'TimerFcn',{@testCycleISMS_callback,hObject,...
    channelsettings,statecounts,walkperiod,samplerate,cyclemult},...
    'StopFcn','toc','StartFcn','tic');
start(handles.timers.timerOL)
wait(handles.timers.timerOL)
delete(timerfind('Name','timerOL'))

function testCycleISMS_callback(obj,~,GUIhObject,channelsettings,...
    statecounts,walkperiod,samplerate,cyclemult)
% this is called to stimulate an OL walking cycle, cycle will repeat for
% cyclemult number of times
h = guidata(GUIhObject);
fwrite(h.serial.serialobj,h.values.stimVector) % pasted from write2ISMS
%implement the open loop algorithm to determine current synergies
currentsynergy = h.values.currentsynergy;
oldsynergy = h.values.oldsynergy;
OLcount = get(obj,'TasksExecuted');
rampcounter = h.values.rampcounter;
fatiguecounter = 0;
loopcount = h.values.loopcount;
if currentsynergy == 1 % F phase
    if loopcount >= statecounts(1) % statecounts for F
        loopcount = 0; % reset loop count for nextloop      
        currentsynergy = 2;
        rampcounter = 1; % refresh ramping
    end
elseif currentsynergy == 2 % E1 phase
    if loopcount >= statecounts(2) % statecounts for E1
        loopcount = 0;                
        currentsynergy = 3;
        rampcounter = 1; % refresh ramping
    end
elseif currentsynergy == 3 % E2 phase
    if loopcount >= statecounts(3) % statecounts for E2
        loopcount = 0;
        currentsynergy = 4;
        rampcounter = 1; % refresh ramping
    end
elseif currentsynergy == 4 % E3 phase
    if loopcount >= statecounts(4) % statecounts for E3
        loopcount = 0;
        currentsynergy = 1;
        rampcounter = 1; % refresh ramping
    end
end
%compute the corresponding channel amplitudes for this time step based on
%the current and old synergies. Ramping is done at the beginning and end of
%the trial, as well as between synergies. Consideration is taken into
%account if the ramping synergies have channels in common or not
chanamps = zeros(16,1); % initialize the amplitudes
active = channelsettings(:,1,currentsynergy) == 1; %indentify active chans
old = channelsettings(:,1,oldsynergy) == 1; %channels previously active
both = (active + old) == 2; %channels previously and are still active
deltaactive = channelsettings(active,3,currentsynergy) - ...
    channelsettings(active,2,currentsynergy);
slopeactive = deltaactive/3;
deltaold = channelsettings(old,3,oldsynergy) - ...
    channelsettings(old,2,oldsynergy);
slopeold = deltaold/3;
deltaoldonly = channelsettings(old ~= both,3,oldsynergy) - ...
    channelsettings(old ~= both,2,oldsynergy);
slopeoldonly = deltaoldonly/3;
deltaactiveonly = channelsettings(active ~= both,3,currentsynergy) - ...
    channelsettings(active ~= both,2,currentsynergy);
slopeactiveonly = deltaactiveonly/3;
deltaoldboth = channelsettings(old - old ~= both,3,oldsynergy) - ...
    channelsettings(old - old ~= both,2,oldsynergy);
slopeoldboth = deltaoldboth/3;
deltaactiveboth = channelsettings(active - active ~= both,3,...
    currentsynergy) - channelsettings(active - active ~= both,2,...
    currentsynergy);
slopeactiveboth = deltaactiveboth/3;
if rampcounter <= 4 % changing synergy, ramp up new and ramp down old
    if OLcount <= 4 % beginning of cycle, ramp up
        chanamps(active,1) = channelsettings(active,2,...
            currentsynergy) + slopeactive*(OLcount - 1);    
    elseif  both == 0 % no channel overlap between new and old synergies
        chanamps(active,1) = channelsettings(active,2,currentsynergy) + ...
            slopeactive*(rampcounter - 1);
        chanamps(old,1) = channelsettings(old,3,oldsynergy) - ...
            slopeold*rampcounter;
        if any(chanamps(old,1) < channelsettings(old,2,oldsynergy))
            chanamps(old,1)=0; % lowest stim = 0
        end
    else % overlap between syns, same chan has small ramp down and up, 
        switch rampcounter % diff chan has oppos ramps
            case 1
                chanamps(both,1) = channelsettings(old - old ~= both,3,...
                    oldsynergy); % start from max for oldsyn
            case 2
                chanamps(both,1) = channelsettings(old - old ~= both,3,...
                    oldsynergy) - slopeoldboth;
            case 3 
                chanamps(both,1) = channelsettings(active - active ~= ...
                    both,3,currentsynergy) - slopeactiveboth;
            case 4
                chanamps(both,1) = channelsettings(active - active ~= ...
                    both,3,currentsynergy); % end with max of currsyn
        end
        chanamps(old ~= both,1) = channelsettings(old ~= both,3,...
            oldsynergy) - slopeoldonly*rampcounter;
        chanamps(active ~= both,1) = channelsettings(active ~= both,2,...
            currentsynergy) + slopeactiveonly*(rampcounter-1);
        if any(chanamps(old ~= both,1)<channelsettings(old ~= both,2,...
                oldsynergy))
            chanamps(old ~= both,1) = 0; % lowest stim = 0
        end
    end
else % not at beginning of a synergy
    if OLcount >= cyclemult*(walkperiod/samplerate) - 2 % end of trial
        chanamps(active,1) = channelsettings(active,3,currentsynergy) - ...
            slopeactive*(OLcount - cyclemult*(walkperiod/samplerate) + 3);
        oldsynergy = 1; 
    else
        chanamps(active) = channelsettings(active,3,currentsynergy);
    end % only update oldsyn after 4 rampcounts to maintain ramping b/w
    oldsynergy = currentsynergy; 
end
if h.developermode
     [h.values.oldchanamps,h.serial,h.values.stimVector] = ...
         write2ISMS(active,currentsynergy,old,h.values.oldsynergy,...
         chanamps,h.values.oldchanamps,channelsettings,h.serial,loopcount);
end
if get(obj,'TasksExecuted') == 1
    beep
end
h.values.rampcounter = rampcounter + 1;
h.values.oldsynergy = oldsynergy;
h.values.loopcount = loopcount + 1;
h.values.currentsynergy = currentsynergy;
guidata(GUIhObject,h)

