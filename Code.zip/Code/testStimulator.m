function testStimulator(hObject,~)
% For testing the output of the stimulator, especially if output does not
% look on time.
% Runs for 1 seconds at 50Hz out of channel 1
handles = guidata(hObject);
handles.values.oldvector=[];
    len = get(handles.serial.serialobj,'BytesAvailable'); % getting info about port
    if len~=0
        a = fread(handles.serial.serialobj,len);
    end
% initialize the timer values
if ~isempty(timerfind('Name','timerStim'))
    delete(timerfind('Name','timerStim'))
end
% hard-code the values in stimVector, the settings for the stimulation
% 165 = communication flag
% 41 and 48 are op codes
% first 0 = channel 1 (the stimulator labels channels 0-15)
% 24 = amplitude of current (multiple of 2s)
% 3 is the code for the 3rd pulse width option = 290us
% both 255s are for breaking down the info into 2 pieces, for interleaving,
% part of the custom mods made by Brad (48 is a custom op code)
stimVector = [165 41 0 100 3 165 48 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 165 48 0 1];
% StimVector above achieves 50Hz total stimulation (25Hz doubled)

timerStim = timer('Period',0.04,'TasksToExecute',100,'BusyMode','drop',...
    'ExecutionMode','FixedRate','Name','timerStim');
set(timerStim,'TimerFcn',{@testStimulator_callback,handles,stimVector});
guidata(hObject,handles)
disp('start')
beep
start(timerStim)
waitfor(timerStim)
stop(timerfind('Name','timerStim'))
delete(timerfind('Name','timerStim'))

function testStimulator_callback(~,~,h,stimVector)
fwrite(h.serial.serialobj,stimVector)
















