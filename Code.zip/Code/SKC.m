function featVect = SKC(K,n,P,c1,c2,c3,S)
%% Selective Kanerva Coder for representing state space made of sensor signals
D = zeros(K,1); % initialize Euclidean distances to zero
% calculate euclidean distances between current state and all prototypes
for i = 1:K
    for j = 1:n
        diffSq(j) = (S(j) - P(i,j))^2;
    end
    D(i) = sqrt(sum(diffSq));
end

% Sort distances in ascending order, retaining index of sorted prototypes
[~,Isort] = sort(D,'ascend');

% get distances corresponding to c-th closest to current state
D1 = Isort(1:c1); % largest eta
D2 = Isort(1:c2);
D3 = Isort(1:c3); % smallest eta

% feature vector contains indices of active prototypes, determined by
% shortest distances from current state
featVect = zeros(K*3,1);

% update feature vector for largest eta
for i = 1:length(D1)
    featVect(D1(i)) = 1;
end

% update feature vector for second eta
D2Ind2Adjust = D2 + K;
for i = 1:length(D2Ind2Adjust)
    featVect(D2Ind2Adjust(i)) = 1; % adjust for multiple etas
end

% update feature vector for smallest eta
D3Ind3Adjust = D3 + K*2;
for i = 1:length(D3Ind3Adjust)
    featVect(D3Ind3Adjust(i)) = 1; % adjust for multiple etas
end