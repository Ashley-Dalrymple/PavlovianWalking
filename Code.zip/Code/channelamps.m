function [chanamps,rampcounter,active,old,oldsyn,rampflag] = ...
    channelamps(channelsettings,stimsynergy,rampcounter,loopcount,...
    RampTimeSteps,rampflag,startflag)
% calculates the amplitudes for each channel based on the current synergy
% and the previous synergy. Ramping occurs at the very beginning and end of
% the trial, as well as in between synergies for smooth transitions.
global data
chanamps = zeros(16,1); % initialize the amplitudes
% if ramping was triggered, over-ride oldsyn so ramping calcs work properly
if stimsynergy == 1
    oldsyn = 4;
else
    oldsyn = stimsynergy - 1;
end
active = channelsettings(:,1,stimsynergy) == 1; % indentify chans active
old = channelsettings(:,1,oldsyn) == 1; %channels previously active: old syn
both = ((active + old) == 2); %channels that were prev active and still active
% calcualte for all active chans, active only, old only, and both
slopeactive = (channelsettings(active,3,stimsynergy) - ...
channelsettings(active,2,stimsynergy))/RampTimeSteps;
slopeactiveonly = (channelsettings(active ~= both,3,stimsynergy) - ...
channelsettings(active ~= both,2,stimsynergy))/RampTimeSteps;
slopeold = (channelsettings(old,3,oldsyn) - ...
channelsettings(old,2,oldsyn))/RampTimeSteps;
slopeoldonly = (channelsettings(old ~= both,3,oldsyn) - ...
channelsettings(old ~= both,2,oldsyn))/RampTimeSteps;
oldbothind = find(and(old,both));
slopeoldboth = (channelsettings(oldbothind,3,oldsyn) - ...
channelsettings(oldbothind,2,oldsyn))/RampTimeSteps;
actbothind = find(and(active,both));
slopeactiveboth = (channelsettings(actbothind,3,stimsynergy) - ...
channelsettings(actbothind,2,stimsynergy))/RampTimeSteps;

if startflag % start of trial
    if loopcount == 1
        chanamps(active,1) = channelsettings(active,2,stimsynergy);
    else
        chanamps(active,1) = data{loopcount - 1,13}(active) + ...
        slopeactive;
    end
elseif rampflag    
    if both == 0 % no channel overlap between new and old synergies 
        if (data{loopcount - 1,13}(active) == 0)
            chanamps(active,1) = channelsettings(active,2,stimsynergy);
        else
            chanamps(active,1) = data{loopcount - 1,13}(active) + slopeactive;
        end
        chanamps(old,1) = data{loopcount - 1,13}(old) - slopeoldonly;
    else % chans in common b/w new and old syns
        if rampcounter == 1
            chanamps(both,1) = data{loopcount - 1,13}(both) - slopeoldboth;
        elseif rampcounter == RampTimeSteps
            chanamps(both,1) = channelsettings(both,3,stimsynergy) - slopeactiveboth;
        else
            chanamps(both,1) = ((data{loopcount - 1,13}(both)) + ...
            channelsettings(both,3,stimsynergy) - slopeactiveboth)/2;
        end
        % still ramp chans not in common
        if (data{loopcount - 1,13}(active ~= both) == 0)
            chanamps(active ~= both,1) = channelsettings(active ~= both,2,stimsynergy);
        else
            chanamps(active ~= both,1) = data{loopcount - 1,13}(active ~= both) + slopeactiveonly;
        end
        chanamps(old ~= both,1) = data{loopcount - 1,13}(old ~= both) - slopeoldonly; 
    end 
else
    chanamps(active) = channelsettings(active,3,stimsynergy);
end

if ~any(roundn(chanamps(old ~= active,1),0) >=  channelsettings(old ~= active,2,oldsyn))
    chanamps(old ~= active,1) = 0; % lowest stim = 0
end
if ~any(roundn(chanamps(both,1),0) >= channelsettings(both,2,stimsynergy))
    chanamps(both,1) = 0; % lowest stim = 0 **** changed from both,2,oldsyn
end
if any(roundn(chanamps(old ~= both,1),0) < channelsettings(old ~= both,2,oldsyn))
    chanamps(old ~= both,1) = 0; % lowest stim = 0 
end
if ~any(roundn(chanamps(active,1),0) >= channelsettings(active,2,stimsynergy))
    chanamps(active,1) = 0; % lowest stim = 0
elseif ~any(roundn(chanamps(active ~= both,1),0) >= channelsettings(active ~= both,2,stimsynergy))
    chanamps(active ~= both,1) = 0;
end

rampcounter = rampcounter+1;


