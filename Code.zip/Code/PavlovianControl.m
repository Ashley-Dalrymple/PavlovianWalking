function handles = PavlovianControl(hObject,~,GUIhObject)
handles = guidata(GUIhObject);
global data
global Originaldata
% At beginning of loop, stimulate for most consistent output
if handles.developermode
    fwrite(handles.serial.serialobj,handles.values.stimVector)
end
% loopcount = get(hObject,'TasksExecuted');
if isempty(data{1,1})
    loopcount = 1;
else
    loopcount = handles.values.loopcount;
end
looptime = handles.values.systemperiod*1000;
numTimeSteps = handles.values.numTimeSteps;
alpha = handles.values.alpha;
lambda = handles.values.lambda;
gamma = [handles.values.gamma1;handles.values.gamma2;handles.values.gamma3];
if loopcount == 1 % first values, from previous file
    featVect = [];
    e = handles.values.etrace;
    w = handles.values.weights;
    Vold = handles.values.Vold;
    maxPUnload = 0;
    maxPForceL = 0;
    maxPGyroL = 0;    
else
    featVect = data{loopcount-1,22};
    e = data{loopcount-1,23};
    w = data{loopcount-1,24};
    Vold = data{loopcount-1,25};
end

% gets new data, clears buffer for next round of data
% [sensordata,~] = xippmex('cont',10245:10252,40,'1ksps'); % disabled for
% demo version
limits = handles.values.limitsettings;

% if ~isempty(sensordata) % commented out for demo, already normalized
% % data from Grapevine
%     ForceL = sensordata(1,:)/1000; % mV to V
%     ForceR = sensordata(2,:)/1000;
%     FxL = sensordata(3,:)/1000;
%     FxR = sensordata(4,:)/1000;
%     GyroL = sensordata(5,:)/1000;
%     GyroR = sensordata(6,:)/1000;
%     Velocity = sensordata(7,:)/1000;
%     LED = sensordata(8,:)/1000;
% end
% % Normalize sensor values to previously determined usable range
% ForceLnorm = (ForceL + 0.5)/3; % normalize
% maxForceL = max(ForceLnorm); % maximize for thresholds later and cumulant
% ForceRnorm = (ForceR + 0.5)/3; % normalize
% SumForce = ((ForceL + ForceR) + 0.5)/4.5; % normalize
% GyroLnorm = (GyroL + 0.5)/1.3; % normalize
% maxGyroL = max(GyroL); % maximize for thresholds later and cumulant
% GyroRnorm = (GyroR + 0.5)/1.3; % normalize

% added in place of data acquisition
ForceLnorm = Originaldata{loopcount,2}(1:40); % normalized
maxForceL = max(ForceLnorm); % maximize for thresholds later and cumulant
ForceRnorm = Originaldata{loopcount,3}(1:40); % normalized
SumForce = Originaldata{loopcount,9}(1:40); % normalized
GyroLnorm = Originaldata{loopcount,6}(1:40); % normalized
GyroL = GyroLnorm*1.3 - 0.5;
maxGyroL = max(GyroL); % maximize for thresholds later and cumulant
GyroRnorm = Originaldata{loopcount,7}(1:40);% normalized

% Get unload function
limbs = handles.values.limbs;
UnloadThresh = (limbs + 0.5)/3.5; % normalize b/c force
LessThresh = UnloadThresh - ForceLnorm; % find force unload
for j = 1:length(LessThresh) 
    if LessThresh(j) < 0
        LessThresh(j) = 0; % set above thresh = 0
    end
end
maxUnload = max(LessThresh); % for cumulant

if loopcount > numTimeSteps % get exponential moving average for making predictions
    longForceL = [];
    longForceR = [];
    for j = 1:numTimeSteps % for last 10 bins
        longForceL = [longForceL,data{(loopcount - (numTimeSteps + 1) + j),2}]; %#ok<*AGROW> % get forces from last 10 bins + current bin
        longForceR = [longForceR,data{(loopcount - (numTimeSteps + 1) + j),3}];
    end
    longForceL = [longForceL,ForceLnorm]; % appedending current data to previous data
    longForceR = [longForceR,ForceRnorm]; % reshape for EMA
    EMAForceL = tsmovavg(longForceL,'e',numTimeSteps*looptime);
    EMAForceR = tsmovavg(longForceR,'e',numTimeSteps*looptime);  
else
    EMAForceL(1:(looptime)) = 0; % EMA = 0 until have enough data for EMA
    EMAForceR(1:(looptime)) = 0;
end 
% make predictions using TOTD for Pavlovian control
Snew = [maxForceL;max(ForceRnorm);max(SumForce);maxGyroL;max(GyroRnorm);max(EMAForceL)]; % state space
Znew = [maxUnload;maxForceL;maxGyroL]; % cumulant signal want to make predictions on
featVectnew = SKC(handles.values.numprototypes,handles.values.numSensors,handles.values.prototypes,handles.values.c1,handles.values.c2,handles.values.c3,Snew); % feature vector from state space and selective kanerva coding
if loopcount > 1
    V = w'*featVect; % True online TD learning
    Vnew = w'*featVectnew;
    TDerr = Znew + gamma.*Vnew - V;
    e = bsxfun(@times,e,(lambda*gamma)') + featVect - featVect*((alpha*lambda*gamma).*(e'*featVect))';
    w = w + bsxfun(@times,e,(alpha*(TDerr + V - Vold))') - featVect*(alpha*(V - Vold))';
    Vold = Vnew;

    oldsyn = data{loopcount-1,11};
    maxPUnload = Vold(1); % new prediction for unloading
    maxPForceL = Vold(2); % new prediction for forceL
    maxPGyroL = Vold(3); % new prediction for gyorL
    deltaForce = maxForceL - data{loopcount-1,14}; % for reaction checks
    deltaPUnload = maxPUnload - data{loopcount-1,16}; % slope of prediction signals
    deltaPForce = maxPForceL - data{loopcount-1,17};
    deltaPGyro = maxPGyroL - data{loopcount-1,18};
    % transition between states using predicted signals, check reactions after no predictions match  
    if ((oldsyn == 3) || (oldsyn == 4)) && (sign(deltaPGyro) == -1) && (maxPGyroL <= limits(9)) && (maxPGyroL >= limits(8))% check prediction
            currsyn = 2; % predicting E1, stim E3
            stimsynergy = 4;
            action = 'predict E1';
    elseif ((oldsyn == 1) || (oldsyn == 2)) && (sign(deltaPForce) == -1) && (maxPForceL >= limits(11)) % check prediction
            currsyn = 7; % predicting E3, stim E1
            stimsynergy = 2;
            action = 'predict E3';
    elseif ((oldsyn == 2) || (oldsyn == 3)) && (sign(deltaPUnload) == 1) && (maxPUnload >= limits(7)) % check prediction
            currsyn = 1; % predicting F, stim E2
            stimsynergy = 3;
            action = 'predict F';
    elseif ((oldsyn == 4) || (oldsyn == 1)) && (maxPForceL >= limits(10)) && (sign(deltaPForce) == 1) % check prediction
            currsyn = 4; % predicting E2, stim F
            stimsynergy = 1;
            action = 'predict E2';
    elseif ((oldsyn == 3) || (oldsyn == 4)) && (maxForceL > limits(13)) && (maxForceL < limits(14)) && (sign(deltaForce) == 1) % check reaction
        currsyn = 2; %  react E1, stim E3
        stimsynergy = 4;
        action = 'react E1';  
    elseif ((oldsyn == 4) || (oldsyn == 1)) && (maxForceL > UnloadThresh) && (sign(deltaForce) == 1) % check reaction
        currsyn = 4; %  react E2, stim F
        stimsynergy = 1;
        action = 'react E2'; 
    elseif ((oldsyn == 2) || (oldsyn == 3)) && (maxForceL < UnloadThresh) && (sign(deltaForce) == -1)  % check reaction
        currsyn = 1; % react F, stim E2
        stimsynergy = 3;
        action = 'react F';
    elseif ((oldsyn == 1) || (oldsyn == 2)) && (maxForceL <= limits(17)) && (maxForceL >= limits(16)) && (sign(deltaForce) == -1)  % check reaction
        currsyn = 7; % react E3, stim E1
        stimsynergy = 2;
        action = 'react E3';
    else % if none of the above matches the data, then stim for prev phase
        action = 'prev';
        if loopcount == 1
            currsyn = 1;
            stimsynergy = 3; % default stim for E2
        else
            currsyn = data{loopcount-1,12};
            stimsynergy = data{loopcount-1,11}; % prev stimsynergy
        end
    end
else
    deltaPUnload = 1; %#ok<*NASGU,*SAGROW> % default to stim E2 or change to E3
    deltaPForce = 1;
    deltaPGyro = -1; % for predicting E3
    currsyn = 1; % predicting F, stim E2
    stimsynergy = 3;
    deltaForce = -1;
    action = 'prev';
end

data{loopcount,11} = stimsynergy; % old synergy = stimsynergy, save here so 
% changes to stim synergy from rules don't interfere with state detection

if (loopcount > 1) && (currsyn ~= data{loopcount - 1,12}) % if new synergy has been detected
    handles.values.rampcounter = 1; % reset the rampcounter
    handles.values.rampflag = true;
    handles.values.startflag = false;
end

if handles.values.rampcounter > handles.values.RampTimeSteps % turn off ramping when done
    handles.values.rampflag = false;    
    handles.values.startflag = false;
end

% compute the corresponding channel amplitudes for this time step based on the current synergies
% Commented out for demo purposes
% [chanamps,handles.values.rampcounter,active,oldchans,oldsynergy,...
%     handles.values.rampflag] = channelamps(handles.values.channelsettings,...
%     stimsynergy,handles.values.rampcounter,loopcount, ...
%     handles.values.RampTimeSteps,handles.values.rampflag,handles.values.startflag);
% now write the channel amplitudes to the stimulator
if handles.developermode
[handles.values.oldchanamps,handles.serial,handles.values.stimVector] = ...
    write2ISMS(active,stimsynergy,oldchans,oldsynergy,chanamps,...
    handles.values.oldchanamps,handles.values.channelsettings,handles.serial,loopcount);
end
% save data
data{loopcount,1} = clock;
data{loopcount,2} = ForceLnorm;
data{loopcount,3} = ForceRnorm;
% data{loopcount,4} = FxL; % never used
% data{loopcount,5} = FxR;
data{loopcount,6} = GyroLnorm;
data{loopcount,7} = GyroRnorm;
% data{loopcount,8} = Velocity; % never used
data{loopcount,9} = SumForce;
% data{loopcount,10} = LED; % for synchronizing data acq and video recording
data{loopcount,12} = currsyn; % currentsynergy = currsyn, for plotting
data{loopcount,14} = maxForceL;
data{loopcount,15} = maxGyroL;
data{loopcount,16} = maxPUnload;
data{loopcount,17} = maxPForceL;
data{loopcount,18} = maxPGyroL;
data{loopcount,19} = EMAForceL((end - looptime + 1):end);
data{loopcount,20} = EMAForceR((end - looptime + 1):end);
data{loopcount,21} = LessThresh;
data{loopcount,22} = featVectnew;
data{loopcount,23} = e;
data{loopcount,24} = w;
data{loopcount,25} = Vold; % predict unload, predict forceL, predict gyroL
data{loopcount,26} = action;
handles.values.loopcount = loopcount + 1;
guidata(GUIhObject,handles)

 