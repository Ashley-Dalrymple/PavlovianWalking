function [old,serialdata,stimVector]=write2ISMS(activein,stimsynergy,...
    oldchans,oldsynergy,chanamps,oldchanamps,chansettings,serialdata,loopcount)
% writes the amplitudes in h.chanamps to the ISMS stimulator
bytecount = 0; % keeping track length of data stream for transmission
stimVector = [];
temp1 = zeros(16,1);
temp2 = zeros(16,1);
stimcurrent = 0; %#ok<NASGU>

global data
% saves cumulative changes to amps 
if loopcount > 0
    data{loopcount,13} = chanamps; 
end

%identify the changed amplitudes and load them
changedchan = find(chanamps ~= oldchanamps); % chann #s changed
if ~isempty(changedchan) % channels amps changed
    % do this as many times as there are channels that have changed
    for i = 1:length(changedchan) 
        stimcurrent = round(chanamps(changedchan(i))/2);
        if stimcurrent > 130 
            stimcurrent = 130;
        end 

        newSettings = [serialdata.tagByte 41 (changedchan(i) - 1) stimcurrent 3];
        stimVector(1,end + 1:end + 5) = newSettings;
        bytecount = bytecount + 5; % 5 = # of bits in newSettings
    end
end
byte1 = 0;
byte2 = 0; 
%identify the interleaved channels
% vector of channels to be interleaved
intchanscurr = setdiff(chansettings(activein,4,stimsynergy),0); 
intchansold = setdiff(chansettings(oldchans,4,oldsynergy),0);
intwith = [];
if isempty(intchanscurr) && isempty(intchansold) 
    intchans = []; % no interleaving for new and old syns
elseif isempty(intchansold) % interleaving in new syn
    intchans = intchanscurr;
    intwith = chansettings(intchans,4,stimsynergy);
elseif isempty(intchanscurr) % interleaving in old syn
    intchans = intchansold;
    intwith = chansettings(intchans,4,oldsynergy); 
elseif stimsynergy ~= oldsynergy % interleaving in both new and old syns,
    intchans = [intchanscurr;intchansold]; % and old & new syns are diff
    intwith = [chansettings(intchans,4,stimsynergy);...
        chansettings(intchans,4,oldsynergy)];
else % old and new syn are the same, and this syn has ramping
    intchans = intchanscurr;
    intwith = chansettings(intchans,4,stimsynergy);
end
if ~isempty(intchans)
    firstround = find(intchans<intwith);
    for i = firstround
        temp1(intwith(i)) = 1;
    end
end
%channels to be stim on round 1
stimfirst1 = find(temp1(1:8) == 0);
stimfirst2 = find(temp1(9:16) == 0);
if ~isempty(stimfirst1)
    byte1 = sum(2.^(stimfirst1 - 1));
end
if ~isempty(stimfirst2)
    byte2 = sum(2.^(stimfirst2 - 1));
end
stimVector(1,end + 1:end + 4) = [serialdata.tagByte 48 byte2 byte1];
bytecount = bytecount + 4;

if bytecount < 96
    filler = 92 - bytecount;
    if filler > 0
    stimVector(1,end + 1:end + filler) = zeros(1,filler);
    end
else %bytecount has to be less than 96
    errordlg('Byte count has been exceeded') 
end
byte1 = 0;
byte2 = 0;
%channels to be stim on round 2
if ~isempty(intchans)
    secondround = find(intchans > intwith);
    for i = secondround
        temp2(intwith(i)) = 1;
    end
end
stimsecond1 = find(temp2(1:8) == 0); 
stimsecond2 = find(temp2(9:16) == 0); 
if ~isempty(stimsecond1)
    byte1 = sum(2.^(stimsecond1 - 1));
end
if ~isempty(stimfirst2)
    byte2 = sum(2.^(stimsecond2 - 1));
end
stimVector(1,end + 1:end + 4) = [serialdata.tagByte 48 byte2 byte1];
old = chanamps;
while ~strcmpi(get(serialdata.serialobj,'TransferStatus'),'idle')
end
% disp('S')