function handles = testOLCycleRecord(hObject)
% this function will test the cycle F-E1-E2-E3 based on an open loop algorithm for
% one walking period, while recording sensor data for both limbs during the
% cycle. The walking period is set in the GUI. Stimulation
% output is 50Hz (25Hz doubled).
handles = guidata(hObject);
% initializations
walkperiod = handles.values.walkingperiod;
cyclemult = handles.values.cyclemultiplier;
samplerate = handles.values.systemperiod;
channelsettings = handles.values.channelsettings;
handles.values.oldchanamps = zeros(16,1);
global data
data = cell(floor(cyclemult*(walkperiod/samplerate)),7); 
handles.values.stimVector = [165 41 0 0 3 165 41 1 0 3 165 41 2 0 3 165 41 3 ...
    0 3 165 41 4 0 3 165 41 5 0 3 165 41 6 0 3 165 41 7 0 3 165 41 8 0 ...
    3 165 41 9 0 3 165 41 10 0 3 165 41 11 0 3 165 48 0 1 0 0 0 0 0 0 0 ...
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 165 48 0 1]; 
handles.values.currentsynergy = 1;
handles.values.oldsynergy = 1;
synergypcts = zeros(4,1);
OLtimes = zeros(1,4); %#ok<PREALL> % from(1,5)
handles.values.rampcounter = 1;
handles.values.loopcount = 0;
synergypcts(1,1) = valuecheck(.2*walkperiod*1000,3,samplerate)/(1000*walkperiod);
synergypcts(2,1) = valuecheck(.2*walkperiod*1000,3,samplerate)/(1000*walkperiod);
synergypcts(4,1) = valuecheck(.3*walkperiod*1000,3,samplerate)/(1000*walkperiod);
synpcts = synergypcts;
synergypcts(3,1) = 1 - sum(synpcts);
OLtimes = synergypcts*walkperiod;
statecounts = round(OLtimes/samplerate);
% check if all synergies are active
if ~all(cell2mat(get(handles.hemipanel.synergybox,'Value'))) % F1, F2, E1, ... 
        savequestion = questdlg('Not all synergies are active.   Enable them all?');
        if strcmpi(savequestion,'yes')
            set(handles.hemipanel.synergybox,'Value',1)
            handles.values.enabledsynergies = ...
                cell2mat(get(handles.hemipanel.synergybox,'Value'));
        end
end 
if handles.developermode
    len = get(handles.serial.serialobj,'BytesAvailable');
    if len ~= 0
        a = fread(handles.serial.serialobj,len);
    end
end
% Record data during testing of walking cycle
handles.values.trialnumber = get(handles.hemipanel.filenameNumber,'String');
trialnumber = (handles.values.trialnumber);
filename = handles.values.filename;

datafilename = strcat(filename,'_',trialnumber);

if ~isempty(timerfind('Name','timerOLrecord'))
    delete(timerfind('Name','timerOLrecord'))
end
h = warndlg('Get Ready!');
uiwait(h)
handles.timers.timerOLrecord = timer('Period',samplerate,'TasksToExecute',...
    floor(cyclemult*(walkperiod/samplerate)),'BusyMode','drop','ExecutionMode',...
    'FixedRate','Name','timerOLrecord');
guidata(hObject,handles)
set(handles.timers.timerOLrecord,'TimerFcn',{@timerOLrecord_callback,hObject,...
    channelsettings,statecounts,walkperiod,samplerate,cyclemult});
tic
start(handles.timers.timerOLrecord)
wait(handles.timers.timerOLrecord)
toc
htosave.channelsettings = handles.values.channelsettings; 
htosave.musclefunctions = handles.values.musclefunctions;
htosave.enabledsynergies = handles.values.enabledsynergies;
htosave.OLtime = handles.values.walkingperiod; 
htosave.cyclemultiplier = handles.values.cyclemultiplier;
htosave.systemperiod = handles.values.systemperiod; 
htosave.limbs = handles.values.limbs; 
htosave.mass = handles.values.mass; 
htosave.limitsettings = handles.values.limitsettings;
htosave.limitsdisplay = handles.values.limitsdisplay;
htosave.trialtime = handles.values.trialtime;  %#ok<*STRNU>
save(datafilename,'data','htosave')
delete(timerfind('Name','timerOLrecord'))
[y,Fs] = audioread('ting.wav');
sound(y,Fs)

function timerOLrecord_callback(obj,~,GUIhObject,channelsettings,...
    statecounts,walkperiod,samplerate,cyclemult)
% this is called to stimulate an OL walking cycle, cycle will repeat for
% cyclemult number of times
handles = guidata(GUIhObject);
global data
OLcount = get(obj,'TasksExecuted');
if handles.developermode
    fwrite(handles.serial.serialobj,handles.values.stimVector)
end
% implement the open loop algorithm to determine current synergies
[sensordata,~] = xippmex('cont',10245:10252,40,'1ksps'); % gets new data
if ~isempty(sensordata)
    ForceR = sensordata(2,:)/1000; % convert to mV
    FxR = sensordata(4,:)/1000;
    GyroR = sensordata(6,:)/1000;
    Velocity = sensordata(7,:)/1000;
    LED = sensordata(8,:)/1000;
else
    ForceR = []; %#ok<*NASGU>
    GyroR = [];
    FxR = [];
    LED = [];
    Velocity = [];
end
currentsynergy = handles.values.currentsynergy;
oldsynergy = handles.values.oldsynergy;
rampcounter = handles.values.rampcounter;
loopcount = handles.values.loopcount;
if currentsynergy == 1 % F phase
    if loopcount >= statecounts(1) % statecounts for F
        loopcount = 0; % reset loop count for nextloop      
        currentsynergy = 2; % transition to new synergy
        rampcounter = 1; % refresh ramping
    end
elseif currentsynergy == 2 % E1 phase
    if loopcount >= statecounts(2) % statecounts for E1
        loopcount = 0;                
        currentsynergy = 3; % transition to new synergy
        rampcounter = 1; % refresh ramping
    end
elseif currentsynergy == 3 % E2 phase
    if loopcount >= statecounts(3) % statecounts for E2
        loopcount = 0;
        currentsynergy = 4; % transition to new synergy
        rampcounter = 1; % refresh ramping
    end
elseif currentsynergy == 4 % E3 phase
    if loopcount >= statecounts(4) % statecounts for E3
        loopcount = 0;
        currentsynergy = 1; % transition to new synergy
        rampcounter = 1; % refresh ramping
    end
end
%compute the corresponding channel amplitudes for this time step based on
%the current and old synergies. Ramping is done at the beginning and end of
%the trial, as well as between synergies. Consideration is taken into
%account if the ramping synergies have channels in common or not
chanamps = zeros(16,1); % initialize the amplitudes
active = channelsettings(:,1,currentsynergy) == 1; %indentifying which channels are active
old = channelsettings(:,1,oldsynergy) == 1; %channels previously active
both = (active + old) == 2; %channels that were previously active and are still active
deltaactive = channelsettings(active,3,currentsynergy) - ...
    channelsettings(active,2,currentsynergy);
slopeactive = deltaactive/3;
deltaold = channelsettings(old,3,oldsynergy) - ...
    channelsettings(old,2,oldsynergy);
slopeold = deltaold/3;
deltaoldonly = channelsettings(old ~= both,3,oldsynergy) - ...
    channelsettings(old ~= both,2,oldsynergy);
slopeoldonly = deltaoldonly/3;
deltaactiveonly = channelsettings(active ~= both,3,currentsynergy) - ...
    channelsettings(active ~= both,2,currentsynergy);
slopeactiveonly = deltaactiveonly/3;
deltaoldboth = channelsettings(old - old ~= both,3,oldsynergy) - ...
    channelsettings(old - old ~= both,2,oldsynergy);
slopeoldboth = deltaoldboth/3;
deltaactiveboth = channelsettings(active - active ~= both,3,...
    currentsynergy) - channelsettings(active - active ~= both,2,...
    currentsynergy);
slopeactiveboth = deltaactiveboth/3;
if rampcounter <= 4 % changing synergy, ramp up new and ramp down old
    if OLcount <= 4 % beginning of cycle, ramp up
        chanamps(active,1) = channelsettings(active,2,currentsynergy) + ...
            slopeactive*(OLcount - 1);    
    elseif  both == 0 % no channel overlap between new and old synergies
        chanamps(active,1) = channelsettings(active,2,currentsynergy) + ...
            slopeactive*(rampcounter - 1);
        chanamps(old,1) = channelsettings(old,3,oldsynergy) - ...
            slopeold*rampcounter;
        if any(chanamps(old,1)<channelsettings(old,2,oldsynergy))
            chanamps(old,1)=0; % lowest stim = 0
        end
    else % overlap b/w syns, same chan has small ramp down and up, 
        switch rampcounter % diff chan has oppos ramps
            case 1
                chanamps(both,1) = channelsettings(old - old ~= both,3,...
                    oldsynergy); % start from max for oldsyn
            case 2
                chanamps(both,1) = channelsettings(old - old ~= both,3,...
                    oldsynergy) - slopeoldboth;
            case 3 
                chanamps(both,1) = channelsettings(active - active ~= ...
                    both,3,currentsynergy) - slopeactiveboth;
            case 4
                chanamps(both,1) = channelsettings(active - active ~= ...
                    both,3,currentsynergy); % end with max of currsyn
        end
        chanamps(old ~= both,1) = channelsettings(old ~= both,3,...
            oldsynergy) - slopeoldonly*rampcounter;
        chanamps(active ~= both,1) = channelsettings(active ~= ...
            both,2,currentsynergy) + slopeactiveonly*(rampcounter - 1);
        if any(chanamps(old ~= both,1) < ...
                channelsettings(old ~= both,2,oldsynergy))
            chanamps(old ~= both,1)=0; % lowest stim = 0
        end
    end
else % not at beginning of a synergy
    if OLcount >= floor(cyclemult*(walkperiod/samplerate)) - 3 % end of trial
        chanamps(active,1) = channelsettings(active,3,currentsynergy) - ...
            slopeactive*(OLcount - floor(cyclemult*(walkperiod/samplerate)) + 3);
        oldsynergy = 1;
    else
        chanamps(active) = channelsettings(active,3,currentsynergy);
    end % only update oldsyn after 3 rampcounts - maintain ramping b/w syns
    oldsynergy = currentsynergy; 
end
if handles.developermode
     [handles.values.oldchanamps,handles.serial,handles.values.stimVector] = ...
         write2ISMS(active,currentsynergy,old,handles.values.oldsynergy,...
     chanamps,handles.values.oldchanamps,channelsettings,handles.serial,loopcount);
end
handles.values.rampcounter = rampcounter + 1;
handles.values.oldsynergy = oldsynergy;
handles.values.loopcount = loopcount + 1;
handles.values.currentsynergy = currentsynergy;
% store values in structure data
data{OLcount,1} = clock;
% data{OLcount,2} = GRFL;
data{OLcount,3} = ForceR;
% data{OLcount,4} = FxL;
data{OLcount,5} = FxR;
% data{OLcount,6} = GyroL;
data{OLcount,7} = GyroR;
data{OLcount,8} = Velocity;
data{OLcount,9} = LED;
data{OLcount,10} = currentsynergy;
data{1,11} = walkperiod;
data{1,12} = cyclemult;
data{OLcount,13} = chanamps;

guidata(GUIhObject,handles)
