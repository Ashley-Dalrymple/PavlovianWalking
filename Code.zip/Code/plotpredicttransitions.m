function plotpredicttransitions(hObject,~)
% This program plots the data from the intact leg being moved by the
% experimenter, along with the phase transitions that were detected by the
% algorithm. 
handles = guidata(hObject);
dataname = uigetfile; % get data from experiment
load(dataname)
figurex = figure;
looptime = htosave.systemperiod*1000;
titleofplot = inputdlg('What is the title of this plot?  ','s');
% preallocated sizes of variables for speed: 
for i = 1:length(data)
    binsize(i) = length(data{i,2}); % get vector of binsizes since not all 
% exactly the same, used for plotting changes in states, need to have 
% proper timestamp
end
currentsynergy = zeros(1,length(data));
for i = 1:(length(data))
   currentsynergy(i) = data{i,12};
end
DiffState = diff(currentsynergy);
% extract actual signals
Unload = [];
ForceL = [];
GyroL = [];
for i = 1:(length(data))
    Unload((1:length(data{(i),21})) + length(Unload)) = data{(i),21}(1:end); 
end
for i = 1:(length(data))
    ForceL((1:length(data{(i),2})) + length(ForceL)) = data{(i),2}(1:end); 
end
for i = 1:(length(data))
    GyroL((1:length(data{(i),6})) + length(GyroL)) = data{(i),6}(1:end); 
end
time = (1:length(ForceL))/1000;

Vold = [];
for i = 1:(length(data))
    Vold(:,i) = data{i,25}(1:end); %#ok<*AGROW>
end
% adjust to time scale
Predict = zeros(length(ForceL),3);
for i = 1:length(Vold)
    Predict((((i-1)*looptime + 1):i*looptime),1) = Vold(1,i); % predict unload
    Predict((((i-1)*looptime + 1):i*looptime),2) = Vold(2,i); % predict forceL
    Predict((((i-1)*looptime + 1):i*looptime),3) = Vold(3,i); % predict gyroL
end

% extract cumulant predictions
UnloadP = Predict(:,1);
ForceP = Predict(:,2);
GyroP = Predict(:,3);

ax1 = subplot(3,1,1);
plot(time,Unload,'k')
hold on
plot(time,UnloadP,'b')
ylo = min(UnloadP) - 1;
yup = max(UnloadP) + 1;
% Find E3 to F: (predict F) - done by unload signal
% actual time stamp is @ loopcount=DiffState+1 but don't +1 b/c works out with binsize
E3toF = find(DiffState == -6); 
if ~isempty(E3toF)
    for i = 1:length(E3toF)
        timeE3F(i) = sum(binsize(1:E3toF(i)))/1000;
        action{i} = data{E3toF(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(timeE3F)
        if strcmp(action{i},'predict F')
            line([timeE3F(i) timeE3F(i)],[ylo yup],'color','r')
        elseif strcmp(action{i},'react F')
            line([timeE3F(i) timeE3F(i)],[ylo yup],'color','r','linestyle','--')
        end
    end
end
% Find E1 to E2: (predict E2) - done by unload signal
E1toE2 = find(DiffState == 2);
if ~isempty(E1toE2)
    for i = 1:length(E1toE2)
        timeE1E2(i) = sum(binsize(1:E1toE2(i)))/1000;
        action{i} = data{E1toE2(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(timeE1E2)
        if strcmp(action{i},'predict E2')
            line([timeE1E2(i) timeE1E2(i)],[ylo yup],'color','m')
        elseif strcmp(action{i},'react E2')
            line([timeE1E2(i) timeE1E2(i)],[ylo yup],'color','m','linestyle','--')
        end
    end
end
ylabel('Unload Signal')

ax2 = subplot(3,1,2);
plot(time,ForceL,'k')
hold on
plot(time,ForceP,'b')
ylo = min(ForceP) - 1;
yup = max(ForceP) + 1;
% Find E2 to E3: (predict E3) - done by force signal
E2toE3 = find(DiffState == 3);
if ~isempty(E2toE3)
    for i = 1:length(E2toE3)
        timeE2E3(i) = sum(binsize(1:E2toE3(i)))/1000;
        action{i} = data{E2toE3(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(timeE2E3)
        if strcmp(action{i},'predict E3')
            line([timeE2E3(i) timeE2E3(i)],[ylo yup],'color','b')
        elseif strcmp(action{i},'react E3')
            line([timeE2E3(i) timeE2E3(i)],[ylo yup],'color','b','linestyle','--')
        end
    end
end
ylabel('Force Left')

ax3 = subplot(3,1,3);
plot(time,GyroL,'k')
hold on
plot(time,GyroP,'b')
ylo = min(GyroP) - 1;
yup = max(GyroP) + 1;
% Find F to E1:  (predict E1) - done by gyro signal
FtoE1 = find(DiffState == 1);
if ~isempty(FtoE1)
    for i = 1:length(FtoE1)
        timeFE1(i) = sum(binsize(1:FtoE1(i)))/1000;
        action{i} = data{FtoE1(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(FtoE1)
        if strcmp(action{i},'predict E1')
            line([timeFE1(i) timeFE1(i)],[ylo yup],'color','g')
        elseif strcmp(action{i},'react E1')
            line([timeFE1(i) timeFE1(i)],[ylo yup],'color','g','linestyle','--')
        end
    end
end
ylabel('Gyro Left')

linkaxes([ax1,ax2,ax3],'x')
xlabel('Time (s)')
title(titleofplot)
