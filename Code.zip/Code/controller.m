function controller
% ISMS controller to restore walking after lateral hemisection SCI
clear all %#ok<CLALL>
handles.developermode = false;
% close existing controller figures
if ~isempty(findobj('Name','Controller')) 
    close(findobj('Name','Controller'))
end
% delete any existing timers, instruments on startup
delete(instrfind) %cleaning things
delete(timerfind)

% create the controller figure (base of GUI)
figureh = figure('Name','Controller','Units','Pixels','Position',...
    [100 50 800 600],'MenuBar','none', 'NumberTitle','Off', 'Resize',...
    'Off', 'Toolbar','none','Visible', 'On', 'Color',[.9,.9,.9]); 

%% Individual Channel and Synergy Settings
handles.panelh.channelspanel = uipanel('Parent',figureh,'Units','Normalized',...
    'Position',[.01 .01 .98 .98],'Tag','channelpanel','Title',...
    'Stimulation Settings','BackgroundColor',[.9 .9 .9],'BorderType',...
    'etchedin','FontSize',10); 
% Initialize controller buttons
handles.channelspanel.initialize = uicontrol(handles.panelh.channelspanel,'Units',...
    'Normalized','Style','pushbutton','Position',[.04 .92 .15 .06],...
    'String','Re-initialize Controller','BackgroundColor',[.9 .9 .9],...
    'Callback',{@initializeISMS_callback});

% test DAQ and stimulator buttons
handles.channelspanel.testDAQ = uicontrol(handles.panelh.channelspanel,'Units',...
    'Normalized','Style','pushbutton','Position',[.24 .92 .12 .06],...
    'String','Test DAQ','BackgroundColor',[.9 .9 .9],'Callback',{@testDAQ});
handles.channelspanel.teststimulator = uicontrol(handles.panelh.channelspanel,...
    'Units','Normalized','Style','pushbutton','Position',...
    [.04 .82 .15 .06],'String','Test Stimulator','BackgroundColor',...
    [.9 .9 .9],'Callback',{@testStimulator});

% Setting properties of channels, synergies. Combo of channels make syns
uicontrol(handles.panelh.channelspanel,'Style','text','String',...
    'Select a Channel:','Units','Normalized','Position',...
    [.5 .95 .15 .04],'BackgroundColor',[.9 .9 .9],'FontSize',10);
handles.channelspanel.selectchannel = uicontrol(handles.panelh.channelspanel,...
    'Style','popupmenu','Units','Normalized','BackgroundColor',[1 1 1],...
    'String',{'1','2','3','4','5','6','7','8','9','10','11','12','13',...
    '14','15','16'},'Position',[.53 .89 .1 .05],'Callback',...
    {@selectchannel_callback});
handles.channelspanel.synergylist = uicontrol(handles.panelh.channelspanel,'Style',...
    'popupmenu','String',{'F','E1','E2','E3'},'Tag','synergymenu',...
    'Units','Normalized','Position',[.75 .84 .1 .1],'BackgroundColor',...
    [1 1 1],'Callback',{@synergies_callback});
uicontrol(handles.panelh.channelspanel,'Style','text','String',...
    'Synergy Group:','Units','Normalized','Position',...
    [.72 .962 .15 .03],'BackgroundColor',[.9 .9 .9],'FontSize',10);
handles.channelspanel.enablestim = uicontrol(handles.panelh.channelspanel,...
    'Style','checkbox','Units','Normalized','BackgroundColor',...
    [.9 .9 .9],'String','Enable Stimulation','Position',[.24 .82 .15 .04],...
    'Value',1,'Callback',{@enablestim_callback});
handles.channelspanel.enablechannel = uicontrol(handles.panelh.channelspanel,...
    'Style','checkbox','Units','Normalized','BackgroundColor',...
    [.9 .9 .9],'String','Enable Channel','Position',[.58 .82 .15 .04],...
    'FontSize',9,'Value',0,'Callback',{@enablechannel_callback});
handles.channelspanel.channellabel = uicontrol(handles.panelh.channelspanel,'Style',...
    'text','Units','Normalized','BackgroundColor',[0 0 0],...
    'ForegroundColor',[1 1 1],'Position',[0 .76 1 .03],'String',...
    'Channel Properties'); 
handles.channelspanel.threshtext(1) = uicontrol(handles.panelh.channelspanel,...
    'Style','text','BackgroundColor',[.9 .9 .9],'Units','Normalized',...
    'String','Motor Threshold (uA):','Position',[.6 .69 .2 .04],...
    'HorizontalAlignment','right','FontSize',9);
handles.channelspanel.threshedit(1) = uicontrol(handles.panelh.channelspanel,...
    'Style','edit','Units','Normalized','BackgroundColor',[1 1 1],...
    'Position',[.81 .7 .15 .04],'Tag','motorthresh','Callback',...
    {@thresh_callback,1});
handles.channelspanel.threshtext(2) = uicontrol(handles.panelh.channelspanel,...
    'Style','text','BackgroundColor',[.9 .9 .9],'Units','Normalized',...
    'String','Max Threshold (uA):','Position',[.6 .63 .2 .04],...
    'HorizontalAlignment','right','FontSize',9);
handles.channelspanel.threshedit(2) = uicontrol(handles.panelh.channelspanel,...
    'Style','edit','Units','Normalized','BackgroundColor',[1 1 1],...
    'Position',[.81 .64 .15 .04],'Tag','maxthresh','Callback',...
    {@thresh_callback,2});
uicontrol(handles.panelh.channelspanel,'Style','text','BackgroundColor',...
    [.9 .9 .9],'Units','Normalized','String','Pulse width: ','Position',...
    [.54 .17 .2 .4],'HorizontalAlignment','right','FontSize',9);
handles.channelspanel.PWpanel = uibuttongroup('Parent',handles.panelh.channelspanel,...
    'Units','Normalized','BackgroundColor',[.9 .9 .9],'BorderType',...
    'etchedin','Title','','Position',[.8 .5 .15 .125],...
    'SelectionChangeFcn',{@pulsewidth_SelectionChangeFcn});
handles.channelspanel.pulsewidth(1) = uicontrol(handles.channelspanel.PWpanel,...
    'Style','radio','Units','Normalized','BackgroundColor',[.9 .9 .9],...
    'String','175 us','Value',0,'Position',[.1 .5 .9 .49],'Tag','PW175');
handles.channelspanel.pulsewidth(2) = uicontrol(handles.channelspanel.PWpanel,...
    'Style','radio','Units','Normalized','BackgroundColor',[.9 .9 .9],...
    'String','290 us','Value',1,'Position',[.1 .01 .9 .49],'Tag','PW290');
uicontrol(handles.panelh.channelspanel,'Style','text','BackgroundColor',...
    [.9 .9 .9],'Units','Normalized','String','Interleave with Channel:',...
    'Position',[.6 .42 .2 .04],'HorizontalAlignment','right','FontSize',9);
handles.channelspanel.interleave = uicontrol(handles.panelh.channelspanel,'Style',...
    'popupmenu','Units','Normalized','BackgroundColor',[1 1 1],'Position',[.81 .43 .15 .04],...
    'Tag','interleave','String',{'none',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16},...
    'Callback',{@interleave_callback});
handles.channelspanel.freqpanel = uibuttongroup('Parent',...
    handles.panelh.channelspanel,'Units','Normalized','BackgroundColor',...
    [.9 .9 .9],'BorderType','etchedin','Title','','Position',[.78 .28 .18 .125],...
    'SelectionChangeFcn',{@freqpanel_SelectionChangeFcn});
uicontrol(handles.panelh.channelspanel,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Normalized','String','Frequency:','Position',[.55 .32 .2 .04],...
    'HorizontalAlignment','right','FontSize',9);
handles.channelspanel.freq(1) = uicontrol(handles.channelspanel.freqpanel,...
    'Style','radio','Units','Normalized','BackgroundColor',[.9 .9 .9],'String',...
    'Low (Interleaving)','Value',0,'Position',[.1 .5 .9 .5],'Tag','freqlow');
handles.channelspanel.freq(2) = uicontrol(handles.channelspanel.freqpanel,'Style',...
    'radio','Units','Normalized','BackgroundColor',[.9 .9 .9],'String',...
    'High (Default)','Value',1,'Position',[.1 .01 .9 .5],'Tag','freqhigh');
handles.channelspanel.musclefunction = uicontrol(handles.panelh.channelspanel,...
    'Style','edit','Units','Normalized','BackgroundColor',[1 1 1],...
    'Position',[.79 .21 .15 .04],'String','','Callback',{@musclefunction_callback});
uicontrol(handles.panelh.channelspanel,'Style','text','Units','Normalized',...
    'BackgroundColor',[.9 .9 .9],'Position',[.61 .21 .17 .04],'String',...
    'Channel Description:','FontSize',9);
handles.channelspanel.testchannelstim = uicontrol(handles.panelh.channelspanel,...
    'Style','pushbutton','String','Test Current Channel','Units',...
    'Normalized','BackgroundColor',[.9 .9 .9],'Position',...
    [.6 .08 .36 .075],'Callback',{@testChannelStim_callback});

% Add a panel of text that will display which channels are currently
% active.  The text must take up to 17 lines maximum such that it can
% handle a title plus all 16 channels
str(1) = {'Properties of Enabled Channels'};
str(3) = {'There are currently no channels enabled'};
handles.channelspanel.reviewactivechannels = uicontrol(handles.panelh.channelspanel,...
    'Style','text','Units','Normalized','BackgroundColor',[1 1 1],...
    'Position',[.01 .01 .55 .75],'String',str);

%% Hemi ISMS Panel
handles.panelh.hemipanel = uipanel('Parent',figureh,'Units','Normalized',...
    'Position',[.01 .01 .98 .98],'Tag','hemipanel','Title','Control Settings',...
    'BackgroundColor',[.9 .9 .9],'BorderType','etchedout','Visible','Off','FontSize',10);
%transition limits for phases
translimits = uipanel('Parent',handles.panelh.hemipanel,'Units','Pixels','Position',[15 10 490 550],...
    'BackgroundColor',[.9 .9 .9],'Title','Synergies and Rule-based Control','FontSize',9);
% get mass of hind limbs for force calculations
uicontrol(translimits,'Style','text','Units','Pixels','Position',[0 490 150 20],...
    'BackgroundColor',[.9 .9 .9],'String','Total Body Mass (kg):');
handles.hemipanel.mass = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [60 470 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@mass_callback});
uicontrol(translimits,'Style','text','Units','Pixels','Position',[10 430 150 20],...
    'BackgroundColor',[.9 .9 .9],'String','Mass of Hind Limbs (kg):');
handles.hemipanel.hindlimbs = uicontrol('Parent',translimits,'Units','Pixels',...
    'Position',[60 410 30 20],'BackgroundColor',[1 1 1],'style','edit','visible','off');

% enable individual synergies
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],'Units','Pixels',...
    'Position',[160 500 130 20],'String','Enable Synergies:','FontSize',9);
handles.hemipanel.synergybox(1) = uicontrol('Parent',translimits,'Style',...
    'checkbox','Value',0,'BackgroundColor',[.9 .9 .9],'Units','Pixels',...
    'Position',[180 480 100 20],'String','F (Early Swing)','Callback',{@enablesyn_callback});
handles.hemipanel.synergybox(2) = uicontrol('Parent',translimits,'Style',...
    'checkbox','Value',0,'BackgroundColor',[.9 .9 .9],'Units','Pixels','Position',...
    [190 455 180 20],'String','E1 (Late Swing to Touchdown)','Callback',{@enablesyn_callback});
handles.hemipanel.synergybox(3) = uicontrol('Parent',translimits,'Style',...
    'checkbox','Value',0,'BackgroundColor',[.9 .9 .9],'Units','Pixels',...
    'Position',[200 430 100 20],'String','E2 (Mid Stance)','Callback',{@enablesyn_callback});
handles.hemipanel.synergybox(4) = uicontrol('Parent',translimits,'Style',...
    'checkbox','Value',0,'BackgroundColor',[.9 .9 .9],'Units','Pixels',...
    'Position',[210 405 100 20],'String','E3 (Propulsion)','Callback',{@enablesyn_callback});

% push buttons for testing aspects of synergies
handles.hemipanel.testsynergybutton = uicontrol('Parent',handles.panelh.hemipanel,...
    'Units','Pixels','Position',[390 515 100 30],'BackgroundColor',[.9 .9 .9],...
    'style','pushbutton','callback',{@testsynergy_callback},'String','Test Synergy');
handles.hemipanel.testcyclebutton = uicontrol('Parent',handles.panelh.hemipanel,...
    'Units','Pixels','Position',[390 475 100 30],'BackgroundColor',[.9 .9 .9],...
    'style','pushbutton','callback',{@testcycle_callback},'String','Test Cycle');
handles.hemipanel.testcyclerecordbutton = uicontrol('Parent',handles.panelh.hemipanel,...
    'Units','Pixels','Position',[375 435 120 30],'BackgroundColor',[.9 .9 .9],...
    'style','pushbutton','callback',{@testcyclerecord_callback},'String','Test Cycle and Record');
uicontrol(handles.panelh.hemipanel,'Units','Pixels','Position',[360 405 100 20],'Style',...
    'text','String','OL Period (s):','BackgroundColor',[.9 .9 .9],'HorizontalAlignment','left');
handles.hemipanel.OLtimeinput = uicontrol(handles.panelh.hemipanel,'Units','Pixels',...
    'Position',[450 408 30 20],'Style','edit','BackgroundColor',[1 1 1],'Callback',{@OLtimeinput_callback});
uicontrol(handles.panelh.hemipanel,'Units','Pixels','Position',[360 380 100 20],'Style',...
    'text','String','# OL Cycles:','BackgroundColor',[.9 .9 .9],'HorizontalAlignment','left');
handles.hemipanel.OLcyclesinput = uicontrol(handles.panelh.hemipanel,'Units','Pixels',...
    'Position',[450 383 30 20],'Style','edit','BackgroundColor',[1 1 1],'Callback',{@OLcyclesinput_callback});

% Labels for phases RBC
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],'Units','Pixels',...
    'Position',[30 365 200 30],'FontSize',10,'String','Rule-Based Control');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[5 345 60 30],'String','Phase of Gait Cycle');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],'Units',...
    'Pixels','Position',[0 320 40 20],'String','F');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[0 290 40 20],'String','E1');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[0 260 40 20],'String','E2');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[0 230 40 20],'String','E3');

% Limits for rule-based control (RBC)
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [30 320 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceL <');
handles.hemipanel.RBC(1) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [95 323 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@RBC_callback,1});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [30 290 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceL <');
handles.hemipanel.RBC(2) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [95 293 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@RBC_callback,2});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [135 290 60 20],'BackgroundColor',[.9 .9 .9],'String','GyroL >');
handles.hemipanel.RBC(3) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [190 293 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@RBC_callback,3});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [30 260 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceL <');
handles.hemipanel.RBC(4) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [95 263 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@RBC_callback,4});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [135 260 60 20],'BackgroundColor',[.9 .9 .9],'String','GyroL <');
handles.hemipanel.RBC(5) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [190 263 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@RBC_callback,5});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [30 230 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceL >');
handles.hemipanel.RBC(6) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [95 233 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@RBC_callback,6});

% Labels for phases
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],'Units','Pixels',...
    'Position',[110 190 200 30],'FontSize',10,'String','Prediction-Based Control');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[5 170 60 30],'String','Phase of Gait Cycle');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[60 165 150 30],'String','Prediction Thresholds');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[195 165 150 30],'String','Reaction Thresholds');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],'Units',...
    'Pixels','Position',[0 130 40 20],'String','F');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[0 100 40 20],'String','E1');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[0 70 40 20],'String','E2');
uicontrol(translimits,'Style','text','BackgroundColor',[.9 .9 .9],...
    'Units','Pixels','Position',[0 40 40 20],'String','E3');
% Thresholds for predictions for PBC
uicontrol(translimits,'Style','text','Units','Pixels','Position',[65 130 80 20],...
    'BackgroundColor',[.9 .9 .9],'String','UnloadP >');
handles.hemipanel.PBC(1) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [135 133 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,1});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [65 100 80 20],'BackgroundColor',[.9 .9 .9],'String','< GyroP <');
handles.hemipanel.PBC(2) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [50 103 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,2});
handles.hemipanel.PBC(3) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [135 103 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,3});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [65 70 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceP >');
handles.hemipanel.PBC(4) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [135 73 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,4});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [65 40 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceP >');
handles.hemipanel.PBC(5) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [135 43 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,5});
% Thresholds for reactions for PBC
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [200 130 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceL <');
handles.hemipanel.PBC(6) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [270 133 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,6});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [240 100 80 20],'BackgroundColor',[.9 .9 .9],'String','< ForceL <');
handles.hemipanel.PBC(7) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [220 103 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,7});
handles.hemipanel.PBC(8) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [310 103 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,8});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [200 70 80 20],'BackgroundColor',[.9 .9 .9],'String','ForceL >');
handles.hemipanel.PBC(9) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [270 73 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,9});
uicontrol(translimits,'Style','text','Units','Pixels','Position',...
    [240 40 80 20],'BackgroundColor',[.9 .9 .9],'String','< ForceL <');
handles.hemipanel.PBC(10) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [220 43 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,10});
handles.hemipanel.PBC(11) = uicontrol('Parent',translimits,'Units','Pixels','Position',...
    [310 43 30 20],'BackgroundColor',[1 1 1],'style','edit','callback',{@PBC_callback,11});

handles.hemipanel.controlenable(1) = uicontrol(translimits,'Style','checkbox','Value',1,...
    'BackgroundColor',[.9 .9 .9],'Units','Pixels','Position',[350 240 150 20],...
    'String','Rule-based control','FontSize',9,'Callback',{@enablecontrol_callback,1});
handles.hemipanel.controlenable(2) = uicontrol(translimits,'Style','checkbox','Value',0,...
    'BackgroundColor',[.9 .9 .9],'Units','Pixels','Position',[350 200 150 20],...
    'String','Pavlovian control','FontSize',9,'Callback',{@enablecontrol_callback,2});
handles.hemipanel.threshplot(8) = uicontrol('Parent',translimits,'Units',...
    'Pixels','Style','pushbutton','Position',[280 325 130 30],'String',...
    'Intact & Stim Alternation','BackgroundColor',[.9 .9 .9],'Callback',{@plotintactstimalt});
handles.hemipanel.threshplot(9) = uicontrol('Parent',translimits,'Units',...
    'Pixels','Style','pushbutton','Position',[280 280 130 30],'String',...
    'Phase Transitions','BackgroundColor',[.9 .9 .9],'Callback',{@plotdatatransitions});
handles.hemipanel.threshplot(10) = uicontrol('Parent',translimits,'Units',...
    'Pixels','Style','pushbutton','Position',[355 110 120 30],'String',...
    'GRF Alternation','BackgroundColor',[.9 .9 .9],'Callback',{@plotGRFaltPredict});
handles.hemipanel.threshplot(11) = uicontrol('Parent',translimits,'Units',...
    'Pixels','Style','pushbutton','Position',[355 65 120 30],'String',...
    'Predict Transitions','BackgroundColor',[.9 .9 .9],'Callback',{@plotpredicttransitions});

learningparams = uipanel('Parent',handles.panelh.hemipanel,'Units','Pixels',...
    'Position',[520 310 250 250],'BackgroundColor',[.9 .9 .9],'Title',...
    'Learning Parameters','FontSize',10);
handles.hemipanel.learningparam(1) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','learning rate (alpha)',...
    'Position',[0.03 0.85 0.8 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(1) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.76 0.88 0.19 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,1});
handles.hemipanel.learningparam(2) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','decay paramter (lambda)',...
    'Position',[0.07 0.73 0.8 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(2) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.76 0.75 0.19 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,2});
handles.hemipanel.learningparam(3) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','discount rate (gammas)',...
    'Position',[0 0.6 0.65 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(3) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.58 0.62 0.12 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,3});
handles.hemipanel.MLsett(4) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.72 0.62 0.12 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,4});
handles.hemipanel.MLsett(5) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.86 0.62 0.12 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,5});
uicontrol(learningparams,'Style','text','Units','Normalized','Position',[0 0.48 0.7 0.1],...
    'BackgroundColor',[.9 .9 .9],'String','Selective Kanerva Coding:','FontSize',9);
handles.hemipanel.learningparam(4) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','prototype ratios (eta)',...
    'Position',[0 0.38 0.55 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(6) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.52 0.4 0.14 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,6});
handles.hemipanel.MLsett(7) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.68 0.4 0.15 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,7});
handles.hemipanel.MLsett(8) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.84 0.4 0.15 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,8});
handles.hemipanel.learningparam(5) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','# of prototypes (K)',...
    'Position',[0.1 0.25 0.6 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(9) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.76 0.27 0.19 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,9});
handles.hemipanel.learningparam(6) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','State space signals',...
    'Position',[0.1 0.15 0.6 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(10) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.76 0.165 0.19 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,10});
handles.hemipanel.learningparam(7) = uicontrol('Parent',learningparams,'Units',...
    'Normalized','Style','text','String','EMA timesteps',...
    'Position',[0.1 0.05 0.5 0.1],'backgroundcolor',[.9 .9 .9]);
handles.hemipanel.MLsett(11) = uicontrol(learningparams,'Style','edit',...
    'Units','Normalized','Position',[0.76 0.06 0.19 0.09],...
    'BackgroundColor',[1 1 1],'callback',{@MLsettcallback,11});

uicontrol(handles.panelh.hemipanel,'Units','Normalized','Position',...
    [.7 .4 .15 .08],'Style','text','String','Trial Duration (s):',...
    'BackgroundColor',[.9 .9 .9],'HorizontalAlignment','left');
handles.hemipanel.trialtimeinput = uicontrol(handles.panelh.hemipanel,'Units',...
    'Normalized','Position',[.82 .45 .06 .04],'Style','edit',...
    'BackgroundColor',[1 1 1],'Callback',{@trialtimeinput_callback});
uicontrol(handles.panelh.hemipanel,'Units','Normalized','Position',...
    [.7 .5 .07 .03],'Style','text','String','Filename: ',...
    'BackgroundColor',[0.9 0.9 0.9], 'HorizontalAlignment','Left');
handles.hemipanel.filenameinput = uicontrol(handles.panelh.hemipanel,...
    'Units','Normalized','Position',[.77 .5 .15 .04],'Style','edit',...
    'BackgroundColor',[1 1 1],'Callback',{@filenameInput_callback});
handles.hemipanel.filenameNumber = uicontrol(handles.panelh.hemipanel,...
    'Units','Normalized','Position',[.93 .5 .03 .04],'Style','edit',...
    'BackgroundColor',[1 1 1],'Callback',{@trialNumberInput_callback});
A = imresize(imread('walkbutton.jpg'),[190,190]);
handles.hemipanel.gobutton = uicontrol(handles.panelh.hemipanel,'Units',...
    'Normalized','Position',[.7 .09 .25 .35],'Style','pushbutton',...
    'BackgroundColor',[.9 .9 .9],'CData',A,'Callback',...
    {@startwalking_callback});
handles.hemipanel.reinitialize = uicontrol(handles.panelh.hemipanel,'Units',...
    'Normalized','Style','pushbutton','Position',[0.75 0.02 0.15 0.05],...
    'String','Reinitialize','BackgroundColor',[.9 .9 .9],'Callback',...
    {@initializeISMS_callback});

%% Analysis Menu
handles.panelh.analysispanel = uipanel('Parent',figureh,'Units','Normalized',...
    'Position',[.01 .01 .98 .98],'Tag','analysispanel','Title',...
    'Plot and Threshold Analysis','BackgroundColor',[.9 .9 .9],...
    'BorderType','etchedout','Visible','Off');

uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[40 500 100 50],'BackgroundColor',[.9 .9 .9],...
    'String','Open Loop Trials:');
handles.hemipanel.threshplot(4) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 490 140 30],'String',...
    'OL Data w/ Transitions','BackgroundColor',[.9 .9 .9],'Callback',...
    {@plotOLtransitions});
uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[40 400 100 50],'BackgroundColor',[.9 .9 .9],...
    'String','Closed Loop Trials:');
handles.hemipanel.threshplot(5) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 390 140 30],'String',...
    'Intact Data w/ Transitions','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotdatatransitions});
handles.hemipanel.threshplot(6) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 350 140 30],'String',...
    'Intact Data w/ Thresholds','BackgroundColor',[.9 .9 .9],....
    'Callback',{@plotdatathresholds});
handles.hemipanel.threshplot(7) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 310 140 30],'String',...
    'Intact & Stim w/ Transitions','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotintactstimtrans});
handles.hemipanel.threshplot(9) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 270 140 30],'String',...
    'Stimd Data w/ Transitions','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotstimtransitions});
handles.hemipanel.threshplot(8) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 230 140 30],'String',...
    'Intact & Stim Data Alternation','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotintactstimalt});
handles.hemipanel.threshplot(28) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[20 190 140 30],'String',...
    'All CL Plots','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotCLall});

uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[240 500 100 50],'BackgroundColor',[.9 .9 .9],...
    'String','Alt. Speed Trials:');
handles.hemipanel.threshplot(14) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 490 140 30],'String',...
    'Speed Change Intact','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotdetectaltspeedintact});
handles.hemipanel.threshplot(12) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 450 140 30],'String',...
    'Speed Change Stim','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotdetectaltspeedstim});
handles.hemipanel.threshplot(13) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 410 140 30],'String',...
    'Speed Change Alternation','BackgroundColor',[.9 .9 .9],...
    'Callback',{@plotdetectaltspeedalt});
handles.hemipanel.threshplot(15) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 370 140 30],'String',...
    'Check Speed Detection','BackgroundColor',[.9 .9 .9],...
    'Callback',{@speeddetectionaccuracy});
uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[240 280 100 50],'BackgroundColor',[.9 .9 .9],...
    'String','Safety Rule Trials:');
handles.hemipanel.threshplot(10) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 270 140 30],'String',...
    'Stimd Data w/ Rules','BackgroundColor',[.9 .9 .9],'Callback',...
    {@plotstimrules});
handles.hemipanel.threshplot(11) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 230 140 30],'String',...
    'Force & Cum-sum w/ Rules','BackgroundColor',[.9 .9 .9],'Callback',...
    {@plotcombinedrules});

uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[240 140 100 50],'BackgroundColor',[.9 .9 .9],...
    'String','Feed Fwd Trials:');
handles.hemipanel.threshplot(29) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 130 140 30],'String',...
    'Feed Fwd Alternation','BackgroundColor',[.9 .9 .9],'Callback',...
    {@plotfeedfwdalt});

uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[230 40 120 50],'BackgroundColor',[.9 .9 .9],...
    'String','Swing-Stance Trials:');
handles.hemipanel.threshplot(30) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[220 30 140 30],'String',...
    'Swing-Stance Alternation','BackgroundColor',[.9 .9 .9],'Callback',...
    {@plotswingstancealt});

% Post-Hoc analysis buttons
uicontrol('Parent',handles.panelh.analysispanel,'Style','text','Units',...
    'Pixels','Position',[440 500 100 50],'BackgroundColor',[.9 .9 .9],...
    'String','Post-Hoc Analysis:');
handles.hemipanel.threshplot(16) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 490 140 30],'String',...
    'Single Step MoTrack','BackgroundColor',[.9 .9 .9],'Callback',...
    {@analysisOfMotion});
handles.hemipanel.threshplot(17) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 450 140 30],'String',...
    'Phase Plot 180','BackgroundColor',[.9 .9 .9],'Callback',...
    {@circlephaseplot180});
handles.hemipanel.threshplot(18) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 410 140 30],'String',...
    'All Data CL','BackgroundColor',[.9 .9 .9],'Callback',...
    {@dataAnalysis});
handles.hemipanel.threshplot(19) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 370 140 30],'String',...
    'All Data OL','BackgroundColor',[.9 .9 .9],'Callback',...
    {@dataAnalysisOL});
handles.hemipanel.threshplot(20) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 330 140 30],'String',...
    'All Data AS','BackgroundColor',[.9 .9 .9],'Callback',...
    {@dataAnalysisAltSpeeds});
handles.hemipanel.threshplot(21) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 290 140 30],'String',...
    'Get Time Loaded','BackgroundColor',[.9 .9 .9],'Callback',...
    {@getTimeLoaded});
handles.hemipanel.threshplot(22) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 250 140 30],'String',...
    'Limb Angle','BackgroundColor',[.9 .9 .9],'Callback',...
    {@indivLimbAngles});
handles.hemipanel.threshplot(23) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 210 140 30],'String',...
    'Limb Angle AS','BackgroundColor',[.9 .9 .9],'Callback',...
    {@indivLimbAnglesAS});
handles.hemipanel.threshplot(24) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 170 140 30],'String',...
    'Show Fatigue','BackgroundColor',[.9 .9 .9],'Callback',...
    {@showFatigue});
handles.hemipanel.threshplot(25) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 130 140 30],'String',...
    'Show Opposition','BackgroundColor',[.9 .9 .9],'Callback',...
    {@showOpposition});
handles.hemipanel.threshplot(26) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 90 140 30],'String',...
    'Synch Video Data','BackgroundColor',[.9 .9 .9],'Callback',...
    {@synchVidData});
handles.hemipanel.threshplot(27) = uicontrol(handles.panelh.analysispanel,'Units',...
    'Pixels','Style','pushbutton','Position',[420 50 140 30],'String',...
    'Time Loaded F/E','BackgroundColor',[.9 .9 .9],'Callback',...
    {@timeloadedFE});

%% Drop Down Menu Buttons
handles.dropdownmenu.file = uimenu(figureh,'Label','File');
handles.dropdownmenu.savesettings = uimenu(handles.dropdownmenu.file,'Label',...
    'Save Current Controller Settings','Callback',{@file_callback,1});
handles.dropdownmenu.loadsettings = uimenu(handles.dropdownmenu.file,'Label',...
    'Load Controller Settings','Callback',{@file_callback,2});
handles.dropdownmenu.exit = uimenu(handles.dropdownmenu.file,'Label','Exit',...
    'Callback',{@file_callback,3});

handles.dropdownmenu.menus = uimenu(figureh,'Label','Select Menu');
handles.dropdownmenu.channelsmenu = uimenu(handles.dropdownmenu.menus,'Label',...
    'Channel Settings','Checked','Off','Callback',{@menu_callback,1});
handles.dropdownmenu.hemimenu = uimenu(handles.dropdownmenu.menus,'Label',...
    'Hemi Settings','Checked','Off','Callback',{@menu_callback,2});
% handles.dropdownmenu.analysismenu = uimenu(handles.dropdownmenu.menus,'Label',...
% 'Analyze Data','Checked','Off','Callback',{@menu_callback,3});

%% Initialization Steps
xippmex('trial','recording');
    % for analog inputs and neural signals (analog inputs from sensors) 
    % cxn b/w sensors and computer, gives comp sampled data    
% Setup data variables
handles.values.channelsettings = zeros(16,6,4);
handles.values.channelsettings(:,5,:) = 2; % set all frequency values high
handles.values.channelsettings(:,6,:) = 3;
handles.values.limitsettings = zeros(1,16); % limits for sensors, detect states
handles.values.limitsdisplay = zeros(1,16); % limits for sensors, detect states
handles.values.mass = [];
handles.values.limbs = 0.625; % for the purpose of having values show up on startup
handles.values.limitsdisplay(1) = 250; % F force RBC
handles.values.limitsettings(1) = handles.values.limbs*(handles.values.limitsdisplay(1)/100);
handles.values.limitsdisplay(2) = 35; % E1 force RBC
handles.values.limitsettings(2) = handles.values.limbs*(handles.values.limitsdisplay(2)/100);
handles.values.limitsettings(3) = 0.13; % E1 gyro RBC
handles.values.limitsdisplay(3) = 0.13;
handles.values.limitsdisplay(4) = 25; % E2 force RBC
handles.values.limitsettings(4) = handles.values.limbs*(handles.values.limitsdisplay(4)/100);
handles.values.limitsettings(5) = 0.01; % E2 gyro RBC
handles.values.limitsdisplay(5) = 0.01;
handles.values.limitsdisplay(6) = 325; % E3 force RBC
handles.values.limitsettings(6) = handles.values.limbs*(handles.values.limitsdisplay(6)/100);
% prediction thresholds
handles.values.limitsdisplay(7) = 0.65; % F unload PBC
handles.values.limitsettings(7) = 0.65;
handles.values.limitsdisplay(8) = 0; % E1 gyro low PBC
handles.values.limitsettings(8) = 0;
handles.values.limitsdisplay(9) = 0.2; % E1 gyro high PBC
handles.values.limitsettings(9) = 0.2;
handles.values.limitsdisplay(10) = 1.55; % E2 unload PBC
handles.values.limitsettings(10) = 1.55;
handles.values.limitsdisplay(11) = 1.2; % E3 force PBC
handles.values.limitsettings(11) = 1.2;

handles.values.limitsdisplay(12) = (handles.values.limbs + 0.5)/3.5; % F force PBC
handles.values.limitsettings(12) = (handles.values.limbs + 0.5)/3.5;
handles.values.limitsdisplay(13) = 0; % E1 force low PBC
handles.values.limitsettings(13) = 0;
handles.values.limitsdisplay(14) = 0.18; % E1 force high PBC
handles.values.limitsettings(14) = 0.18;
handles.values.limitsdisplay(15) = (handles.values.limbs + 0.5)/3.5; % E2 force PBC
handles.values.limitsettings(15) = (handles.values.limbs + 0.5)/3.5;
handles.values.limitsdisplay(16) = 0.34; % E3 force low PBC
handles.values.limitsettings(16) = 0.34;
handles.values.limitsdisplay(17) = 0.7; % E3 force high PBC
handles.values.limitsettings(17) = 0.7;

handles.values.musclefunctions = cell(16,1);
handles.values.activechannel = 1;
handles.values.activesynergy = 1;
handles.values.trialtime = 0;
handles.values.DAQtrialtime = 10;
handles.values.walkingperiod = 2;
handles.values.cyclemultiplier = 1;
handles.values.systemperiod = 0.04; 
handles.values.filename = 'default_';
handles.values.trialnumber = '1';
handles.values.enabledsynergies = cell2mat(get(handles.hemipanel.synergybox,'Value'));
handles.values.stimchannels = 16;
handles.values.monobox=1;
handles.values.rampcounter = 1;
handles.values.RBC = true;
handles.values.alpha = 0.001;
handles.values.lambda = 0.9;
handles.values.gamma1 = 0.9;
handles.values.gamma2 = 0.71;
handles.values.gamma3 = 0.75;
handles.values.eta1 = 0.1;
handles.values.eta2 = 0.025;
handles.values.eta3 = 0.005;
handles.values.numprototypes = 5000;
handles.values.prevfilename = [];
handles.values.c1 = handles.values.numprototypes*handles.values.eta1;
handles.values.c2 = handles.values.numprototypes*handles.values.eta2;
handles.values.c3 = handles.values.numprototypes*handles.values.eta3;
handles.values.numSensors = 6;
handles.values.numTimeSteps = 10; % for exponential moving average
handles.values.featVect = zeros(15000,1);
load('SKC6sensors')
handles.values.prototypes = P;

% initialize all the components of the controller GUI
handles = startupinit(handles,0);

% make channels menu visible, all others off
set(handles.panelh.channelspanel,'Visible','On');
set(handles.panelh.hemipanel,'Visible','Off');
set(handles.panelh.analysispanel,'Visible','Off');
% check the channels menu drop down button
set(handles.dropdownmenu.channelsmenu,'Checked','On');
set(handles.dropdownmenu.hemimenu,'Checked','Off');
% set(handles.dropdownmenu.analysismenu,'Checked','Off');
set(figureh,'visible','on')
if handles.developermode
    handles = initializeISMS(handles,figureh); % initialize controller on startup
end
guidata(figureh,handles) 

%% Callback functions: 
%Drop Down Menus
function menu_callback(hObject,~,panelselect)
% toggle between panels and check the active panel
% 1: channels, 2: hemilesion 3: analysis
handles = guidata(hObject);
switch panelselect
    case 1 % channels panel
        set(handles.panelh.channelspanel,'Visible','On');
        set(handles.panelh.hemipanel,'Visible','Off');
        set(handles.panelh.analysispanel,'Visible','Off');
        set(handles.dropdownmenu.channelsmenu,'Checked','On');
        set(handles.dropdownmenu.hemimenu,'Checked','Off');
        set(handles.dropdownmenu.analysismenu,'Checked','Off');
    case 2 % hemilesion panel
        set(handles.panelh.channelspanel,'Visible','Off');
        set(handles.panelh.hemipanel,'Visible','On');
        set(handles.panelh.analysispanel,'Visible','Off');
        set(handles.dropdownmenu.channelsmenu,'Checked','Off');
        set(handles.dropdownmenu.hemimenu,'Checked','On');
%         set(handles.dropdownmenu.analysismenu,'Checked','Off');
%     case 3 % hemilesion panel
%         set(handles.panelh.channelspanel,'Visible','Off');
%         set(handles.panelh.hemipanel,'Visible','Off');
%         set(handles.panelh.analysispanel,'Visible','On');
%         set(handles.dropdownmenu.channelsmenu,'Checked','Off');
%         set(handles.dropdownmenu.hemimenu,'Checked','Off');
%         set(handles.dropdownmenu.analysismenu,'Checked','On');
end
guidata(hObject,handles)

function file_callback(hObject,~,optionselect)
% execute file command: 1: save, 2: load, 3: exit
handles = guidata(hObject);
switch optionselect
    case 1  % save all the values used in the controller
        htosave.channelsettings = handles.values.channelsettings; 
        htosave.musclefunctions = handles.values.musclefunctions;
        htosave.enabledsynergies = handles.values.enabledsynergies;
        htosave.OLtime = handles.values.walkingperiod; 
        htosave.cyclemultiplier = handles.values.cyclemultiplier;
        htosave.systemperiod = handles.values.systemperiod; 
        htosave.limbs = handles.values.limbs; 
        htosave.mass = handles.values.mass; 
        htosave.limitsettings = handles.values.limitsettings;
        htosave.limitsdisplay = handles.values.limitsdisplay;
        htosave.alpha = handles.values.alpha;
        htosave.lambda = handles.values.lambda;
        htosave.gamma1 = handles.values.gamma1;
        htosave.gamma2 = handles.values.gamma2;
        htosave.gamma3 = handles.values.gamma3;
        htosave.eta1 = handles.values.eta1;
        htosave.eta2 = handles.values.eta2;
        htosave.eta3 = handles.values.eta3;
        htosave.numprototypes = handles.values.numprototypes;
        htosave.numSensors = handles.values.numSensors;
        htosave.numTimeSteps = handles.values.numTimeSteps; 
        htosave.trialtime = handles.values.trialtime;  %#ok<STRNU>
        uisave('htosave');

    case 2 % loading settings file
        uiload  % need to have backwards compatability (more complicated than just loading values)
        if exist('htosave') %#ok<EXIST>
            handles.values.channelsettings = htosave.channelsettings;  %#ok<NODEF>
            handles.values.musclefunctions = htosave.musclefunctions;
            handles.values.enabledsynergies = htosave.enabledsynergies ;
            handles.values.walkingperiod = htosave.OLtime;
            handles.values.cyclemultiplier = htosave.cyclemultiplier;
            handles.values.systemperiod = htosave.systemperiod;
            handles.values.limbs = htosave.limbs;
            handles.values.mass = htosave.mass;
            handles.values.limitsettings = htosave.limitsettings;
            handles.values.limitsdisplay = htosave.limitsdisplay;
            handles.values.alpha = htosave.alpha;
            handles.values.lambda = htosave.lambda;
            handles.values.gamma1 = htosave.gamma1;
            handles.values.gamma2 = htosave.gamma2;
            handles.values.gamma3 = htosave.gamma3;
            handles.values.eta1 = htosave.eta1;
            handles.values.eta2 = htosave.eta2;
            handles.values.eta3 = htosave.eta3;
            handles.values.numprototypes = htosave.numprototypes;
            handles.values.numSensors = htosave.numSensors;
            handles.values.numTimeSteps = 10; 
            handles.values.c1 = handles.values.numprototypes*handles.values.eta1;
            handles.values.c2 = handles.values.numprototypes*handles.values.eta2;
            handles.values.c3 = handles.values.numprototypes*handles.values.eta3;
            handles.values.trialtime = htosave.trialtime;
        end
           handles = startupinit(handles,1);
           if handles.developermode
                handles = initializeISMS(handles,hObject);
           end
           guidata(hObject,handles)
           
    case 3
        savequestion = ...
            questdlg('Do you want to save settings before exiting?',...
            'Save before exiting');
        if strcmpi(savequestion,'yes')
            values = handles.values; %#ok<NASGU>
            uisave('values');
        end
        if ~strcmpi(savequestion,'cancel')
            close
        end
end

%% Channel Setting Callback
function initializeISMS_callback(hObject,~)
handles = guidata(hObject);
handles = initializeISMS(handles,hObject);
guidata(hObject,handles)

function handles = initializeISMS(handles,guiobj)
% initializes the  stimulator
%delete any existing timers and ports
delete(instrfind)
delete(timerfind)

%commonly used parameters, default settings for Phil's serial comm, these
%are non-adjustable, will need to be changed if using a different
%stimulator
handles.serial.tagByte = 165;
handles.serial.unitAddress = 31;
if handles.values.monobox == 1
    handles.serial.balanced = 0; %biased=0;
    handles.serial.biphasic = 0; %mono=0;
else
    handles.serial.balanced = 1; %biased=0;
    handles.serial.biphasic = 1;
end
handles.serial.amp = 0;
handles.serial.pulsewidth = 0;
handles.serial.firstAnodic = 0;
handles.serial.hardwareAssert = 0;
handles.serial.trainEnable = 0; 
handles.serial.trainPhase = 0;
handles.serial.trainClock = 0; 
handles.serial.highAnodic = 1;
handles.serial.highCathodic = 1;
handles.serial.masterEnable = 1;
handles.serial.bytelog = 0;
handles.serial.bytei = 1;
if handles.developermode
    wb = waitbar(0,'Initializing Serial Port');
    %open serial port on COM1
    handles.serial.serialobj = serial('COM1','BaudRate',38400);
    set(handles.serial.serialobj,'BytesAvailableFcnCount',150);
    set(handles.serial.serialobj,'BytesAvailableFcnMode','byte');
    fopen(handles.serial.serialobj);
    waitbar(0.2,wb,'Clearing Serial Buffers');
    len = get(handles.serial.serialobj,'BytesAvailable');
    if len ~= 0
        a = fread(handles.serial.serialobj,len); %#ok<NASGU>
    end
    guidata(guiobj,handles)
    waitbar(0.3,wb,'Resetting Stimulator');
    %reset stim box
    moduleReset = [handles.serial.tagByte 1 handles.serial.unitAddress];
          handles.serial.bytelog(1,end+1:end+3)=moduleReset;
    fwrite(handles.serial.serialobj,moduleReset);
    pause(0.1)%wait 0.1s before doing more, waiting for serial to catch up
    %increase limits
    waitbar(0.4,wb,'Setting Limits');
    limitIncrease = [handles.serial.tagByte 2 handles.serial.unitAddress ...
        handles.serial.highAnodic handles.serial.highCathodic];
        handles.serial.bytelog(1,end+1:end+5)=limitIncrease; %creating strings 
        % of bytes/commands for the controller to recognize
    fwrite(handles.serial.serialobj,limitIncrease);
    pause(0.1)
    
    %load default settings into all channels
    for channel=0:15
        waitbar(0.4+(channel/15)*0.6,wb,...
            sprintf('Engaging channel: %d',channel+1));
        initialParaA=[handles.serial.tagByte 41 channel handles.serial.amp...
            handles.serial.pulsewidth]; 
            handles.serial.bytelog(1,end+1:end+5)=initialParaA;

        initialParaB=[handles.serial.tagByte 5 handles.serial.unitAddress channel ...
            handles.serial.hardwareAssert handles.serial.trainEnable ...
            handles.serial.trainPhase handles.serial.trainClock];
                handles.serial.bytelog(1,end+1:end+8)=initialParaB;

        initialDrivers=[handles.serial.tagByte 3 handles.serial.unitAddress channel ...
            handles.serial.biphasic handles.serial.balanced];
        handles.serial.bytelog(1,end+1:end+6)=initialDrivers;
                guidata(guiobj,handles)
                fwrite(handles.serial.serialobj,initialParaA)
                        pause(0.02)
                        fwrite(handles.serial.serialobj,initialParaB)
                                pause(0.02)
                                fwrite(handles.serial.serialobj,initialDrivers)
                                        pause(0.02)
    end
waitbar(1,wb,'Success!');
pause(1)
close(wb)
end

function selectchannel_callback(hObject,~)
handles = guidata(hObject);
handles.values.activechannel = get(hObject,'Value');
handles = updatechannelpanel(handles);
guidata(hObject,handles);

function synergies_callback(hObject,~)
handles = guidata(hObject);
handles.values.activesynergy = get(hObject,'Value');
handles = updatechannelpanel(handles);
guidata(hObject,handles)

function enablestim_callback(hObject,~)
handles = guidata(hObject);
handles.developermode = get(hObject,'Value'); % loads program w/out external cxns
handles = updatechannelpanel(handles);
guidata(hObject,handles);

function enablechannel_callback(hObject,~)
handles = guidata(hObject);
handles.values.channelsettings(handles.values.activechannel,1,...
    handles.values.activesynergy)=get(hObject,'Value');
handles = updatechannelpanel(handles);
guidata(hObject,handles);

function thresh_callback(hObject,~,whichthresh)
handles = guidata(hObject);
newval = str2double(get(hObject,'string')); %user input of threshold
if isnan(newval)
    newval = 0;
    set(handles.channelspanel.threshedit(whichthresh),'String','0')
end
handles.values.channelsettings(handles.values.activechannel,whichthresh+1,...
    handles.values.activesynergy)=valuecheck(newval,1);
handles = updatechannelpanel(handles);
guidata(hObject,handles);

function pulsewidth_SelectionChangeFcn(hObject,eventdata)
handles = guidata(hObject);
switch get(eventdata.NewValue,'Tag')
    case 'PW175'
        handles.values.channelsettings(handles.values.activechannel,6,:)=2;
    case 'PW290'
        handles.values.channelsettings(handles.values.activechannel,6,:)=3;
    otherwise 
        handles.values.channelsettings(handles.values.activechannel,6,:)=3;
end
handles = updatechannelpanel(handles);
guidata(hObject,handles)

function interleave_callback(hObject,~)
handles = guidata(hObject);
newinterleave = get(hObject,'value')-1;
oldinterleave = handles.values.channelsettings(handles.values.activechannel,4,...
    handles.values.activesynergy);
handles.values.channelsettings(handles.values.activechannel,4,...
    handles.values.activesynergy) = newinterleave;
if newinterleave ~=0
    handles.values.channelsettings(newinterleave,4,...
        handles.values.activesynergy) = handles.values.activechannel;
    handles.values.channelsettings(newinterleave,5,handles.values.activesynergy) = 1;
    handles.values.channelsettings(handles.values.activechannel,5,...
        handles.values.activesynergy) = 1;
else
    handles.values.channelsettings(handles.values.activechannel,5,:) = 2;
end
if oldinterleave~=0
    handles.values.channelsettings(oldinterleave,4,:) = 0;
    handles.values.channelsettings(oldinterleave,5,:) = 2;
end
set(handles.channelspanel.freqpanel,'SelectedObject',...
    handles.channelspanel.freq(handles.values.channelsettings(handles.values.activechannel,...
    5,handles.values.activesynergy)))
handles = updatechannelpanel(handles);
guidata(hObject,handles)

function freqpanel_SelectionChangeFcn(hObject,eventdata)
handles = guidata(hObject);
switch lower(get(eventdata.NewValue,'Tag'))
    case 'freqhigh'
        handles.values.channelsettings(handles.values.activechannel,5,:)=2;
    case 'freqlow'
        handles.values.channelsettings(handles.values.activechannel,5,:)=1;
end
handles = updatechannelpanel(handles);
guidata(hObject,handles)

function musclefunction_callback(hObject,~) % ie. hip flexion, TA
handles = guidata(hObject);
handles.values.musclefunctions{handles.values.activechannel} = get(hObject,'string');
handles = updatechannelpanel(handles);
guidata(hObject,handles)

function testChannelStim_callback(hObject,~) 
handles = guidata(hObject);
[y,Fs] = audioread('ting.wav');
sound(y,Fs)
guidata(hObject,handles);
testChannel(hObject);

function mass_callback(hObject,~)
handles = guidata(hObject);
handles.values.mass = str2double(get(handles.hemipanel.mass,'String'));
handles.values.limbs = handles.values.mass*0.125;
handles.values.limitsdisplay(12) = (handles.values.limbs + 0.5)/3.5; % for limits relative to unload
handles.values.limitsettings(12) = (handles.values.limbs + 0.5)/3.5;
handles.values.limitsdisplay(15) = (handles.values.limbs + 0.5)/3.5;
handles.values.limitsettings(15) = (handles.values.limbs + 0.5)/3.5;
set(handles.hemipanel.hindlimbs,'Visible','on','string',...
    num2str(handles.values.limbs)); % update limb mass
set(handles.hemipanel.PBC(6),'string',num2str(handles.values.limitsdisplay(12)));
set(handles.hemipanel.PBC(9),'string',num2str(handles.values.limitsdisplay(15)));
guidata(hObject,handles)

function enablesyn_callback(hObject,~)
handles = guidata(hObject);
handles.values.enabledsynergies = cell2mat(get(handles.hemipanel.synergybox,'Value'));
guidata(hObject,handles);

function testsynergy_callback(hObject,~)
handles = guidata(hObject);
guidata(hObject,handles)
testSynergy(hObject);

function testcycle_callback(hObject,~) 
handles = guidata(hObject);
guidata(hObject,handles)
testOLCycle(hObject);

function testcyclerecord_callback(hObject,~) 
handles = guidata(hObject);
trialnum = str2double(handles.values.trialnumber);
testOLCycleRecord(hObject);
trialnumber = trialnum + 1;
handles.values.trialnumber = num2str(trialnumber);
set(handles.hemipanel.filenameNumber,'String',handles.values.trialnumber)
guidata(hObject,handles)

function OLtimeinput_callback(hObject,~)
handles = guidata(hObject);
handles.values.walkingperiod = str2double(get(handles.hemipanel.OLtimeinput,'String'));
guidata(hObject,handles);

function OLcyclesinput_callback(hObject,~)
handles = guidata(hObject);
handles.values.cyclemultiplier = str2double(get(handles.hemipanel.OLcyclesinput,...
    'String'));
guidata(hObject,handles);

function RBC_callback(hObject,~,limit)
handles = guidata(hObject);
limbs = handles.values.limbs; % force as % of limb mass
if ~isempty(limbs)
switch limit
    case 1
        FForce = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(1) = FForce;
        handles.values.limitsettings(1) = limbs*(FForce/100);
    case 2
        E1Force = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(2) = E1Force;
        handles.values.limitsettings(2) = limbs*(E1Force/100);
    case 3
        E1Gyro = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(3) = E1Gyro;
        handles.values.limitsettings(3) = E1Gyro;
    case 4
        E2Force = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(4) = E2Force;
        handles.values.limitsettings(4) = limbs*(E2Force/100); 
     case 5
        E2Gyro = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(5) = E2Gyro;
        handles.values.limitsettings(5) = E2Gyro;
    case 6
        E3Force = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(6) = E3Force;
        handles.values.limitsettings(6) = limbs*(E3Force/100); 
end 
else
    warndlg('Please enter the mass of the animal before setting limits!')
end
guidata(hObject,handles)

function PBC_callback(hObject,~,limit)
handles = guidata(hObject); % limits raw vals b/c normalized data
switch limit
    case 1
        FUnloadP = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(7) = FUnloadP;
        handles.values.limitsettings(7) = FUnloadP;
    case 2
        E1GyroPLow = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(8) = E1GyroPLow;
        handles.values.limitsettings(8) = E1GyroPLow;
    case 3
        E1GyroPHigh = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(9) = E1GyroPHigh;
        handles.values.limitsettings(9) = E1GyroPHigh;
    case 4
        E2ForceP = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(10) = E2ForceP;
        handles.values.limitsettings(10) = E2ForceP;
    case 5
        E3ForceP = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(11) = E3ForceP;
        handles.values.limitsettings(11) = E3ForceP;    
     case 6
        FForce = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(12) = FForce;
        handles.values.limitsettings(12) = FForce;
    case 7
        E1ForceLow = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(13) = E1ForceLow;
        handles.values.limitsettings(13) = E1ForceLow; 
    case 8
        E1ForceHigh = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(14) = E1ForceHigh;
        handles.values.limitsettings(14) = E1ForceHigh;
    case 9
        E2Force = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(15) = E2Force;
        handles.values.limitsettings(15) = E2Force;
    case 10
        E3ForceLow = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(16) = E3ForceLow;
        handles.values.limitsettings(16) = E3ForceLow;
    case 11
        E3ForceHigh = str2double(get(hObject,'String'));
        handles.values.limitsdisplay(17) = E3ForceHigh;
        handles.values.limitsettings(17) = E3ForceHigh;
end            
guidata(hObject,handles)

function enablecontrol_callback(hObject,~,enable)
handles = guidata(hObject);
switch enable
    case 1 % only one type of control allowed at a time
        controlenable = get(handles.hemipanel.controlenable(1),'value');
        if controlenable % RBC is enabled
            set(handles.hemipanel.controlenable(2),'value',0); % disable Pavlovian control
            handles.values.RBC = true;
        else % RBC is not enabled
            set(handles.hemipanel.controlenable(2),'value',1);
            handles.values.RBC = false;
        end
    case 2
        controlenable = get(handles.hemipanel.controlenable(2),'value');
        if controlenable % Pavlovian control is enabled
            set(handles.hemipanel.controlenable(1),'value',0); % disable RBC
            handles.values.RBC = false;
        else
            set(handles.hemipanel.controlenable(1),'value',1); % enable RBC
            handles.values.RBC = true;
        end
    case 3
        controlenable = get(handles.hemipanel.controlenable(3),'value');
        if controlenable
            handles.values.fatigue = true;
        else
            handles.values.fatigue = false;
        end
end
guidata(hObject,handles);


function MLsettcallback(hObject,~,val)
handles = guidata(hObject);
switch val
    case 1
        handles.values.alpha = str2double(get(hObject,'String'));
    case 2
        handles.values.lambda = str2double(get(hObject,'String'));
    case 3
        handles.values.gamma1 = str2double(get(hObject,'String'));
    case 4
        handles.values.gamma2 = str2double(get(hObject,'String'));
    case 5
        handles.values.gamma3 = str2double(get(hObject,'String'));
    case 6
        handles.values.eta1 = str2double(get(hObject,'String'));
        handles.values.c1 = handles.values.numprototypes/handles.values.eta1;
    case 7
        handles.values.eta2 = str2double(get(hObject,'String'));
        handles.values.c2 = handles.values.numprototypes/handles.values.eta2;
    case 8
        handles.values.eta3 = str2double(get(hObject,'String'));
        handles.values.c3 = handles.values.numprototypes/handles.values.eta3;
    case 9
        handles.values.numprototypes = str2double(get(hObject,'String'));
        handles.values.c1 = handles.values.numprototypes/handles.values.eta1;
        handles.values.c2 = handles.values.numprototypes/handles.values.eta2;
        handles.values.c3 = handles.values.numprototypes/handles.values.eta3;
    case 10
        handles.values.numSensors = str2double(get(hObject,'String'));
    case 11
        handles.values.numTimeSteps = str2double(get(hObject,'String'));
end
guidata(hObject,handles)

function trialtimeinput_callback(hObject,~)
handles = guidata(hObject);
handles.values.trialtime = str2double(get(handles.hemipanel.trialtimeinput,'String'));
guidata(hObject,handles)

function filenameInput_callback(hObject,~)
handles = guidata(hObject);
handles.values.filename = get(handles.hemipanel.filenameinput,'String');
guidata(hObject,handles)

function trialNumberInput_callback(hObject,~)
handles = guidata(hObject);
handles.values.trialnumber = get(handles.hemipanel.filenameNumber,'String');
guidata(hObject,handles)

function startwalking_callback(hObject,~)
handles = guidata(hObject);
trialnum = str2double(handles.values.trialnumber);
startwalking(hObject)
trialnumber = trialnum + 1;
handles.values.trialnumber = num2str(trialnumber);
set(handles.hemipanel.filenameNumber,'String',handles.values.trialnumber)
handles = initializeISMS(handles,hObject); 
guidata(hObject,handles)



