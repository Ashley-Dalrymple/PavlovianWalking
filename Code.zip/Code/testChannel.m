function handles = testChannel(hObject)
% tests the active channel of the stimulator for 1 second with ramping over
% 3 timesteps. Stimulation output is 50Hz (25Hz doubled)
handles = guidata(hObject);
trialtime = 1;  %1 second stimulation
handles.values.oldchanamps = zeros(16,1);
handles.values.stimVector = [165 41 0 0 3 165 41 1 0 3 165 41 2 0 3 165 41 3 ...
    0 3 165 41 4 0 3 165 41 5 0 3 165 41 6 0 3 165 41 7 0 3 165 41 8 0 ...
    3 165 41 9 0 3 165 41 10 0 3 165 41 11 0 3 165 48 0 1 0 0 0 0 0 0 ...
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 165 48 0 1]; 
    len = get(handles.serial.serialobj,'BytesAvailable');
    if len ~= 0
        a = fread(handles.serial.serialobj,len);
    end
% initialize the timer values
handles.values.activecount = 1;
if ~isempty(timerfind('Name','timerChannel'))
    delete(timerfind('Name','timerChannel'))
end
activein = handles.values.activechannel; %channel selected to test stim
currentsynergy = handles.values.activesynergy;
channelsettings = handles.values.channelsettings;
delta = channelsettings(activein,3,currentsynergy) - ...
    channelsettings(activein,2,currentsynergy);
slope = delta/3;
handles.timers.timerChannel = timer('Period',handles.values.systemperiod,...
    'TasksToExecute',floor(trialtime/handles.values.systemperiod),'BusyMode',...
    'drop','ExecutionMode','FixedRate','Name','timerChannel');
%setup the timer function that will reload the amplitudes each time
set(handles.timers.timerChannel,'TimerFcn',{@testChannel_callback,hObject,...
    activein,channelsettings,slope,currentsynergy,trialtime});
guidata(hObject,handles)
start(handles.timers.timerChannel)
wait(handles.timers.timerChannel)
delete(timerfind('Name','timerChannel'))

function testChannel_callback(~,~,GUIobj,activein,channelsettings,...
    slope,currentsynergy,trialtime)
%testStimISMS:  this function will be called each time the timer toggles,
%the function will load the parameters for the channel being tested into
%the stimulator (ISMS) and then execute the pulse
h = guidata(GUIobj);
fwrite(h.serial.serialobj,h.values.stimVector)
activecount = h.values.activecount; % initialized to 1
chanamps = zeros(h.values.stimchannels,1); % reset chanamps each loop
samplerate = h.values.systemperiod; %seconds 
if activecount <= 4 % Increasing stim with iteration, max by 4th time step
    chanamps(activein,1) = slope*(activecount-1) + ...
        channelsettings(activein,2,currentsynergy);
    if any(chanamps(activein,1) > channelsettings(activein,3,currentsynergy))
        % ensure do not stim higher than max
        chanamps(activein,1) = channelsettings(activein,3,currentsynergy); 
    end
elseif activecount >= ((trialtime/samplerate) - 2) % Decr. stim to thresh
    chanamps(activein,1) = channelsettings(activein,2,currentsynergy) + ...
        slope*((trialtime/samplerate) - activecount);
    if any(chanamps(activein,1) < channelsettings(activein,2,currentsynergy)) 
        chanamps(activein,1) = 0; % lowest stim = 0
    end 
else % Constant stim at max
    chanamps(activein,1) = channelsettings(activein,3,currentsynergy);
end
% make sure channel is active - check enable
chanamps(1:16,1) = chanamps(1:16,1).*channelsettings(1:16,1,...
    currentsynergy);
% because only testing 1 channel, turn off the non active channels
chanamps(1:16 ~= activein,1) = 0;

%write data to stimulator
if h.developermode
     [h.values.oldchanamps,h.serial,h.values.stimVector] = ...
         write2ISMS(activein,currentsynergy,activein,currentsynergy,...
         chanamps,h.values.oldchanamps,channelsettings,h.serial,activecount);
end
if activecount == 1
    beep
end
h.values.activecount = activecount + 1;
guidata(GUIobj,h);
