function handles = startupinit(handles,loadFlag)
% this function initializes all of the controller GUI components 

% components in the channel panel
set(handles.channelspanel.synergylist,'Value',handles.values.activesynergy)
set(handles.channelspanel.selectchannel,'Value',handles.values.activechannel)
set(handles.channelspanel.enablechannel,'Value',...
    handles.values.channelsettings(handles.values.activechannel,1,...
    handles.values.activesynergy))
set(handles.channelspanel.threshedit(1),'String',...
    num2str(handles.values.channelsettings(handles.values.activechannel,2,...
    handles.values.activesynergy)))
set(handles.channelspanel.threshedit(2),'String',...
    num2str(handles.values.channelsettings(handles.values.activechannel,3,...
    handles.values.activesynergy)))
set(handles.channelspanel.freqpanel,'SelectedObject',handles.channelspanel.freq(2))
% components in the hemi panel
set(handles.hemipanel.trialtimeinput,'String',num2str(handles.values.trialtime))
set(handles.hemipanel.OLtimeinput,'String',num2str(handles.values.walkingperiod))
set(handles.hemipanel.OLcyclesinput,'String',num2str(handles.values.cyclemultiplier))

set(handles.hemipanel.RBC(1),'String',handles.values.limitsdisplay(1))
set(handles.hemipanel.RBC(2),'String',handles.values.limitsdisplay(2))
set(handles.hemipanel.RBC(3),'String',handles.values.limitsettings(3))
set(handles.hemipanel.RBC(4),'String',handles.values.limitsdisplay(4))
set(handles.hemipanel.RBC(5),'String',handles.values.limitsettings(5))
set(handles.hemipanel.RBC(6),'String',handles.values.limitsdisplay(6))
set(handles.hemipanel.PBC(1),'String',handles.values.limitsettings(7))
set(handles.hemipanel.PBC(2),'String',handles.values.limitsettings(8))
set(handles.hemipanel.PBC(3),'String',handles.values.limitsettings(9))
set(handles.hemipanel.PBC(4),'String',handles.values.limitsettings(10))
set(handles.hemipanel.PBC(5),'String',handles.values.limitsettings(11))
set(handles.hemipanel.PBC(6),'String',handles.values.limitsettings(12))
set(handles.hemipanel.PBC(7),'String',handles.values.limitsettings(13))
set(handles.hemipanel.PBC(8),'String',handles.values.limitsettings(14))
set(handles.hemipanel.PBC(9),'String',handles.values.limitsettings(15))
set(handles.hemipanel.PBC(10),'String',handles.values.limitsettings(16))
set(handles.hemipanel.PBC(11),'String',handles.values.limitsettings(17))

set(handles.hemipanel.MLsett(1),'String',num2str(handles.values.alpha))
set(handles.hemipanel.MLsett(2),'String',num2str(handles.values.lambda))
set(handles.hemipanel.MLsett(3),'String',num2str(handles.values.gamma1))
set(handles.hemipanel.MLsett(4),'String',num2str(handles.values.gamma2))
set(handles.hemipanel.MLsett(5),'String',num2str(handles.values.gamma3))
set(handles.hemipanel.MLsett(6),'String',num2str(handles.values.eta1))
set(handles.hemipanel.MLsett(7),'String',num2str(handles.values.eta2))
set(handles.hemipanel.MLsett(8),'String',num2str(handles.values.eta3))
set(handles.hemipanel.MLsett(9),'String',num2str(handles.values.numprototypes))
set(handles.hemipanel.MLsett(10),'String',num2str(handles.values.numSensors))
set(handles.hemipanel.MLsett(11),'String',num2str(handles.values.numTimeSteps))
set(handles.hemipanel.filenameinput,'String',handles.values.filename)
set(handles.hemipanel.filenameNumber,'String',handles.values.trialnumber)

if loadFlag % loading previously saved settings
    set(handles.hemipanel.synergybox(1),'Value',handles.values.enabledsynergies(1))
    set(handles.hemipanel.synergybox(2),'Value',handles.values.enabledsynergies(2))
    set(handles.hemipanel.synergybox(3),'Value',handles.values.enabledsynergies(3))
    set(handles.hemipanel.synergybox(4),'Value',handles.values.enabledsynergies(4))
    set(handles.hemipanel.mass,'String',handles.values.mass)
    set(handles.hemipanel.hindlimbs,'visible','on','String',handles.values.limbs)
    set(handles.channelspanel.enablechannel,'Value',...
        handles.values.channelsettings(handles.values.activechannel,1,handles.values.activesynergy))
    handles = updatechannelpanel(handles);
end