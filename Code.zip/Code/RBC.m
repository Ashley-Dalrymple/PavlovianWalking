function handles = RBC(hObject,~,GUIhObject) % Rule-based control
handles = guidata(GUIhObject);
global data
% At beginning of loop, stimulate for most consistent output
if handles.developermode
    fwrite(handles.serial.serialobj,handles.values.stimVector)
end
loopcount = get(hObject,'TasksExecuted');

% get new data, clears buffer for next round of data
[sensordata,~] = xippmex('cont',10245:10252,40,'1ksps');

if ~isempty(sensordata)
% data from Grapevine
    GRFL = sensordata(1,:)/1000; % mV to V
    GRFR = sensordata(2,:)/1000;
    FxL = sensordata(3,:)/1000;
    FxR = sensordata(4,:)/1000;
    GyroL = sensordata(5,:)/1000;
    GyroR = sensordata(6,:)/1000;
    Velocity = sensordata(7,:)/1000;
    LED = sensordata(8,:)/1000;
    SumF = GRFL + GRFR;
end
limits = handles.values.limitsettings;
maxForceL = max(GRFL); % max force value for intact leg
maxGyroL = max(GyroL);% max gyro value for intact leg
if loopcount > 1 
    deltaF = maxForceL - data{loopcount - 1,14}; % slope of force data (6)
    deltaG = maxGyroL - data{loopcount - 1,15}; % slope of gyro data (7)
    oldsyn = data{loopcount - 1,11}; % get old stim synergy saved from last loop
else % if loopcount = 1
    oldsyn = 3; % initialize oldsyn to be E2
    deltaF = -1;
    deltaG = 0;
end
% Algorithm for detecting states of walking cycle in control limb
if ((oldsyn == 3) || (oldsyn == 4)) && (sign(deltaG) == 1) && (maxForceL <= limits(2)) && (maxGyroL >= limits(3))
    currsyn = 2; % anticipating E1
    stimsynergy = 4;
elseif ((oldsyn == 4) || (oldsyn == 1)) && (maxForceL <= limits(4)) && (sign(deltaG) == -1) && (maxGyroL <= limits(5))
    currsyn = 4; % anticipating E2
    stimsynergy = 1;
elseif ((oldsyn == 2) || (oldsyn == 3)) && (sign(deltaF) == -1) && ((maxForceL <= limits(1)))  
    currsyn = 1; % anticipating F
    stimsynergy = 3;
elseif ((oldsyn == 1) || (oldsyn == 2)) && (sign(deltaF) == 1) && (maxForceL >= limits(6))
    currsyn = 7; % anticipating E3
    stimsynergy = 2;
else % if none of the above matches the data, then stim for prev phase
    if loopcount == 1
        currsyn = 1;
        stimsynergy = 3; % default stim for E2         
    else
    currsyn = data{loopcount - 1,12};
    stimsynergy = oldsyn; % prev stimsynergy
    end
end 
data{loopcount,11} = stimsynergy; % old synergy = stimsynergy, save here so 
% changes to stim synergy from rules don't interfere with state detection

if (loopcount > 1) && (currsyn ~= data{loopcount - 1,12}) % if new synergy has been detected
    handles.values.rampcounter = 1; % reset the rampcounter
    handles.values.rampflag = true;
    handles.values.startflag = false;
end
if handles.values.rampcounter > handles.values.RampTimeSteps % turn off ramping when done
    handles.values.rampflag = false;    
    handles.values.startflag = false;
end

% compute the corresponding channel amplitudes for this time step based on the current synergies
[chanamps,handles.values.rampcounter,active,oldchans,oldsynergy,...
    handles.values.rampflag] = channelamps(handles.values.channelsettings,...
    stimsynergy,handles.values.rampcounter,loopcount, ...
    handles.values.RampTimeSteps,handles.values.rampflag,handles.values.startflag);
% now write the channel amplitudes to the stimulator
if handles.developermode
[handles.values.oldchanamps,handles.serial,handles.values.stimVector] = ...
    write2ISMS(active,stimsynergy,oldchans,oldsynergy,chanamps,...
    handles.values.oldchanamps,handles.values.channelsettings,handles.serial,loopcount);
end
% save data
data{loopcount,1} = clock;
data{loopcount,2} = GRFL;
data{loopcount,3} = GRFR;
data{loopcount,4} = FxL;
data{loopcount,5} = FxR;
data{loopcount,6} = GyroL;
data{loopcount,7} = GyroR;
data{loopcount,8} = Velocity;
data{loopcount,9} = SumF;
data{loopcount,10} = LED; % for synchronizing data acq and video recording
data{loopcount,12} = currsyn; % currentsynergy = currsyn, for plotting
data{loopcount,14} = maxForceL;
data{loopcount,15} = maxGyroL;

guidata(GUIhObject,handles)

 