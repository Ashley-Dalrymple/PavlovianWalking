function handles = testSynergy(hObject)
% stimulates the active synergy, which can be made of multiple channels,
% for 1 second with ramping up and down over 3 timesteps. Can only
% stimulate 1 synergy at a time.  Stimulation output is 50Hz (25Hz doubled)
handles = guidata(hObject);
trialtime = 1;  %1 second stimulation
gotime = false;
handles.values.oldchanamps = zeros(16,1);
handles.values.stimVector = [165 41 0 0 3 165 41 1 0 3 165 41 2 0 3 165 41 3 ...
    0 3 165 41 4 0 3 165 41 5 0 3 165 41 6 0 3 165 41 7 0 3 165 41 8 0 ...
    3 165 41 9 0 3 165 41 10 0 3 165 41 11 0 3 165 48 0 1 0 0 0 0 0 0 0 ...
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 165 48 0 1]; 
enabledsynergies = cell2mat(get(handles.hemipanel.synergybox,'Value'));
if sum(enabledsynergies) > 1
    handles = ...
        warndlg('More than 1 synergy is active (only 1 can be active)',...
        'Set active synergy');
    uiwait(handles)    
else
    gotime = true;
end
if gotime
len = get(handles.serial.serialobj,'BytesAvailable');
if len ~= 0
    a = fread(handles.serial.serialobj,len);
end
handles.values.activecount = 1;
if ~isempty(timerfind('Name','timerSynergy'))
    delete(timerfind('Name','timerSynergy'))
end
currentsynergy = find(enabledsynergies == 1);
activein = find(handles.values.channelsettings(:,1,currentsynergy) == 1);
channelsettings = handles.values.channelsettings;
delta = channelsettings(activein,3,currentsynergy) - ...
    channelsettings(activein,2,currentsynergy);
slope = delta/3;
handles.timers.timerSynergy = timer('Period',handles.values.systemperiod,...
    'TasksToExecute',trialtime/handles.values.systemperiod,'BusyMode','drop',...
    'ExecutionMode','FixedRate','Name','timerSynergy');
%setup the timer function that will reload the amplitudes each time
set(handles.timers.timerSynergy,'TimerFcn',{@testsynergy_callbackISMS,...
    hObject,currentsynergy,slope,activein,channelsettings,trialtime});
guidata(hObject,handles);
disp('start')
start(handles.timers.timerSynergy)
wait(handles.timers.timerSynergy)
delete(timerfind('Name','timerSynergy'))
end

function testsynergy_callbackISMS(obj,~,GUIobj,currentsynergy,slope,...
    activein,channelsettings,trialtime)
%testSynergy: this is the timer callback for timerSynergy which is the
% each time this callback is performed,
%the current active synergy is already set by testSynergyISMS file which
%creates the timer.  this function will determine whether ramping is in
%order by figuring out how much time has passed.  ramping occurs in the
%first and last 0.1 seconds of the 1 second stimulus
handles = guidata(GUIobj);
fwrite(handles.serial.serialobj,handles.values.stimVector)
activecount = handles.values.activecount;
chanamps = zeros(handles.values.stimchannels,1);
samplerate = handles.values.systemperiod; %seconds 
if ~any(activein)
    warndlg('No active channels in selected synergy')
    stop(obj)
end
if activecount <= 4 % Increase stim with iteration, max by 4th time step
    chanamps(activein,1) = slope*(activecount - 1) + ...
        channelsettings(activein,2,currentsynergy);
    if any(chanamps(activein,1) > ...
            channelsettings(activein,3,currentsynergy))
        chanamps(activein,1) = channelsettings(activein,3,currentsynergy);
    end
elseif activecount >= ((trialtime/samplerate) - 2) % Decr. Sstim to thresh
    chanamps(activein,1) = channelsettings(activein,2,currentsynergy) + ...
        slope*((trialtime/samplerate) - activecount);
    if any(chanamps(activein,1) < ...
            channelsettings(activein,2,currentsynergy))
        chanamps(activein,1) = 0; % lowest stim = 0
    end
else % constant stim
    chanamps(activein,1) = channelsettings(activein,3,currentsynergy);  
end
%write data to stimulator
if handles.developermode
     [handles.values.oldchanamps,handles.serial,handles.values.stimVector] = ...
         write2ISMS(activein,currentsynergy,activein,currentsynergy,...
         chanamps,handles.values.oldchanamps,channelsettings,handles.serial,activecount);
end
if activecount == 1
    beep
end
handles.values.activecount = activecount + 1;
guidata(GUIobj,handles);
