function output = valuecheck(varargin)
% checks the value of the input based on the selected type, if using times
% need to pass systemperiod as varargin{3}
input = varargin{1};
type = varargin{2};

switch type
    case 1 %amplitude 2 uA increments up to 254
        lower = 0;
        upper = 254;
        increment = 2;
        range = lower:increment:upper;
    case 2 %pulse width (us)
        lower = 175;
        upper = 290;
        %increment=115;
        range = lower:upper;
    case 3 % ramp percents
        lower = 0;
        upper = 6014;
        increment = varargin{3}*1000;
        range = lower:increment:upper;

end
[r, c] = size(input);
output = zeros(r,c);
for i = 1:c
    for ii = 1:r
        value = input(ii,i);
        [~, ind] = min(abs(value - range));
        output(ii,i) = range(ind);
    end
end