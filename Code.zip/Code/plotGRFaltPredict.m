function plotGRFaltPredict(hObject,~)
handles = guidata(hObject);
dataname = uigetfile; % get data from experiment
load(dataname)
figurex = figure;
titleofplot = inputdlg('What is the title of this plot?  ','s');
for i = 1:length(data)
    binsize(i) = length(data{i,2}); % get vector of binsizes since not all 
% exactly the same, used for plotting changes in states, need to have 
% proper timestamp
end
ForceL = [];
ForceR = [];
currentsynergy = zeros(1,length(data));
for i = 1:(length(data))
    ForceL((1:length(data{(i),2})) + length(ForceL)) = data{(i),2}(1:end); 
end
for i = 1:(length(data))
    ForceR((1:length(data{(i),3})) + length(ForceR)) = data{(i),3}(1:end); 
end
time = (1:length(ForceL))/1000;
plot(time,ForceL,'k')
hold on
plot(time,ForceR,'color',[0.7 0.5 0])

ylo = min(ForceL) - 1;
yup = max(ForceL) + 1;

for i = 1:(length(data))
   currentsynergy(i) = data{i,12};
end
DiffState = diff(currentsynergy);
% Find E3 to F: 
% actual time stamp is @ loopcount=DiffState+1 but don't +1 
% b/c works out with binsize
E3toF = find(DiffState == -6);
if ~isempty(E3toF)
    for i = 1:length(E3toF)
        timeE3F(i) = sum(binsize(1:E3toF(i)))/1000;
        action{i} = data{E3toF(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(timeE3F)
        if strcmp(action{i},'predict F')
            line([timeE3F(i) timeE3F(i)],[ylo yup],'color','r')
        elseif strcmp(action{i},'react F')
            line([timeE3F(i) timeE3F(i)],[ylo yup],'color','r','linestyle','--')
        end
    end
end
% Find F to E1: 
FtoE1 = find(DiffState == 1);
if ~isempty(FtoE1)
    for i = 1:length(FtoE1)
        timeFE1(i) = sum(binsize(1:FtoE1(i)))/1000;
        action{i} = data{FtoE1(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(FtoE1)
        if strcmp(action{i},'predict E1')
            line([timeFE1(i) timeFE1(i)],[ylo yup],'color','g')
        elseif strcmp(action{i},'react E1')
            line([timeFE1(i) timeFE1(i)],[ylo yup],'color','g','linestyle','--')
        end
    end
end
% Find E1 to E2:
E1toE2 = find(DiffState == 2);
if ~isempty(E1toE2)
    for i = 1:length(E1toE2)
        timeE1E2(i) = sum(binsize(1:E1toE2(i)))/1000;
        action{i} = data{E1toE2(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(timeE1E2)
        if strcmp(action{i},'predict E2')
            line([timeE1E2(i) timeE1E2(i)],[ylo yup],'color','m')
        elseif strcmp(action{i},'react E2')
            line([timeE1E2(i) timeE1E2(i)],[ylo yup],'color','m','linestyle','--')
        end
    end
end
% Find E2 to E3:
E2toE3 = find(DiffState == 3);
if ~isempty(E2toE3)
    for i = 1:length(E2toE3)
        timeE2E3(i) = sum(binsize(1:E2toE3(i)))/1000; %#ok<*AGROW>
        action{i} = data{E2toE3(i)+1,26}; % prediction or reaction?
    end
    for i = 1:length(timeE2E3)
        if strcmp(action{i},'predict E3')
            line([timeE2E3(i) timeE2E3(i)],[ylo yup],'color','b')
        elseif strcmp(action{i},'react E3')
            line([timeE2E3(i) timeE2E3(i)],[ylo yup],'color','b','linestyle','--')
        end
    end
end
xlabel('Time (s)')
ylabel('Normalized forces')
title(titleofplot)

annotation(figurex,'textbox',[0.75 0.78 0.1 0.1],'string','Swing',...
    'color','r','edgecolor','none','FitBoxToText','off');
annotation(figurex,'textbox',[0.8 0.78 0.1 0.1],'string','Touchdown',...
    'color','g','edgecolor','none','FitBoxToText','off');
annotation(figurex,'textbox',[0.75 0.76 0.1 0.1],'string','Stance',...
    'color','m','edgecolor','none','FitBoxToText','off');
annotation(figurex,'textbox',[0.8 0.76 0.1 0.1],'string','Push-off',...
    'color','b','edgecolor','none','FitBoxToText','off');
str = {'State Transitions Detected:'};
annotation(figurex,'textbox',[0.75 0.83 0.1 0.08],'string',str);
annotation(figurex,'textbox',[0.76 0.75 0.1 0.05],'string',...
    'Intact Side','color','k','edgecolor','none','FitBoxToText','off');
annotation(figurex,'textbox',[0.8 0.75 0.1 0.05],'string',...
    'Stim Side','color',[0.7 0.5 0],'edgecolor','none','FitBoxToText',...
    'off');
str = {'Force Traces:'};
annotation(figurex,'textbox',[0.75 0.77 0.1 0.05],'string',str);




