function handles =  testDAQ(hObject,~)
% If concerned data collection not working, run this program to record
% data from the grapevines
handles = guidata(hObject);
trialtime = handles.values.DAQtrialtime;
systemperiod = handles.values.systemperiod;
global data

data = cell(floor(trialtime/systemperiod),9);

datafilename = input('Please enter a filename for the data: ','s');

if ~isempty(timerfind('Name','timerDAQ'))
    delete(timerfind('Name','timerDAQ'));
end
handles.timers.timerDAQ = timer('Period',systemperiod,...
    'TasksToExecute',trialtime/systemperiod,'BusyMode','drop',...
    'ExecutionMode','FixedRate','Name','timerDAQ');

set(handles.timers.timerDAQ,'TimerFcn',{@getDAQData,hObject},...
    'StopFcn','toc','StartFcn','tic');
guidata(hObject,handles)   
start(handles.timers.timerDAQ)
wait(handles.timers.timerDAQ)
save(datafilename,'data')
delete(timerfind('Name','timerDAQ'))   
    
function getDAQData(obj,~,GUIhObject)
handles = guidata(GUIhObject);
global data
count = get(obj,'TasksExecuted');
[sensordata,~] = xippmex('cont',10245:10252,40,'1ksps');

if ~isempty(sensordata)
    GRFL = sensordata(1,:)/1000;
    GRFR = sensordata(2,:)/1000; % convert to mV
    FxL = sensordata(3,:)/1000;
    FxR = sensordata(4,:)/1000;
    GyroL = sensordata(5,:)/1000;
    GyroR = sensordata(6,:)/1000;
    Velocity = sensordata(7,:)/1000;
    LED = sensordata(8,:)/1000;
else
    [GRFL,GRFR,FxL,FxR,GyroL,GyroR,Velocity,LED] = deal([]);
end
data{count,1} = clock;
data{count,2} = GRFL;
data{count,3} = GRFR;
data{count,4} = FxL;
data{count,5} = FxR;
data{count,6} = GyroL;
data{count,7} = GyroR;
data{count,8} = Velocity;
data{count,9} = LED;

guidata(GUIhObject,handles)